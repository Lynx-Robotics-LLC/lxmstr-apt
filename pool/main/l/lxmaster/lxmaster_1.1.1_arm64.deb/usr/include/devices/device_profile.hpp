#pragma once

#include "devices/device_lifecycle.hpp"

#include <cstdint>
#include <string>

namespace ecdev {

class ISlaveServices;
class ProcessImage;
class IMotionProfile;
class IIoProfile;
class IEncoderProfile;

/**
 * Device-class behaviour plugged onto a {@link GenericEniDevice}. A profile understands the PDO
 * semantics of one EtherCAT device class (CiA 402 drive, CiA 401 digital/analog I/O, CiA 406
 * encoder, ...) and nothing about the backend, the ENI XML, or the master. It interacts with the world
 * through exactly two narrow contracts:
 *
 *   - {@link ISlaveServices} for setup-time SDO / register / PDO-pulse work (NOT on the RT path).
 *   - {@link ProcessImage} for per-cycle reads/writes of mapped objects (RT path).
 *
 * Selection is done by a {@link ProfileRegistry}; a new device class is added by registering a
 * new profile, with no change to the generic device or the orchestration layer.
 *
 * Threading: `configurePreOp`/`prepareSafeOp`/shutdown hooks run on the bring-up/shutdown thread
 * while the bus is not in OPERATIONAL; `writeOutputs`/`readInputs` run on the RT cyclic thread.
 * A profile that exposes data to application threads must do so through its own lock-free state
 * (e.g. atomics), exactly as the facades expect.
 */
class IDeviceProfile : public IDeviceLifecycle {
public:
  ~IDeviceProfile() override = default;

  /** Stable identifier for diagnostics (e.g. `"CiA402-drive"`).
   * @return A null-terminated string literal naming this profile class. Must be stable for the
   *         lifetime of the profile object (a string literal in practice). */
  virtual const char* profileName() const = 0;

  /**
   * Resolve the static channel/PDO topology from the ENI-derived process image. Called once when
   * the profile is attached to its device (during binding, before `start()`), so facade capability
   * queries such as `IIoProfile::digitalOutputCount()` are valid as soon as the bus is bound —
   * before any live PRE_OP SDO work. The image carries only ENI geometry here (it is not yet bound
   * to the live IOmap), which is all a structural resolve needs. Default: no-op. Idempotent:
   * `configurePreOp` may resolve again from the same image during `start()`.
   * @param image ENI-derived process image carrying the PDO geometry for this slave.
   */
  virtual void resolveTopology(const ProcessImage& image) { (void)image; }

  /**
   * Perform CoE / SDO configuration while the slave is in PRE_OP (bus not cycling). Resolve
   * process-image handles (PDO objects) for use in the cyclic path. Called on the bring-up thread;
   * never on the RT thread.
   * @param svc Slave services handle for SDO reads/writes and register access.
   * @param image Process image for this slave; resolve PDO entry handles here for later cyclic use.
   * @return Empty string on success; a non-empty human-readable reason string aborts bring-up.
   */
  virtual std::string configurePreOp(ISlaveServices& svc, ProcessImage& image) {
    (void)svc;
    (void)image;
    return {};
  }
  /**
   * Final configuration step before OPERATIONAL: the slave is in SAFE_OP and the PDO IOmap is
   * live but outputs are not yet driven. Use this for last-moment readiness checks or any SDO
   * writes that must happen after the IOmap is mapped. Called on the bring-up thread; never on
   * the RT thread.
   * @param svc Slave services handle for SDO reads/writes.
   * @param image Live process image (IOmap is mapped but outputs are not yet driven).
   * @return Empty string on success; a non-empty human-readable reason string aborts bring-up.
   */
  virtual std::string prepareSafeOp(ISlaveServices& svc, ProcessImage& image) {
    (void)svc;
    (void)image;
    return {};
  }

  /**
   * Write output PDO values for this cycle. Called on the RT cyclic thread every cycle while
   * OPERATIONAL.
   * @param image Live PDO byte map for this slave's output objects; write target values into it.
   * @param cycle_count Total RT cycles executed since `start()` (monotonically increasing).
   */
  virtual void writeOutputs(ProcessImage& image, std::uint64_t cycle_count) {
    (void)image;
    (void)cycle_count;
  }
  /**
   * Read input PDO values captured this cycle. Called on the RT cyclic thread every cycle while
   * OPERATIONAL. Profiles should guard state updates on `wkc_valid` and `operational` to avoid
   * acting on stale data.
   * @param image Live PDO byte map for this slave's input objects.
   * @param wkc_valid False when the work counter dropped this cycle — the slave may not have
   *                  responded and input data may be stale.
   * @param operational False during the OP-entry cooldown cycles after the master enters
   *                    OPERATIONAL. Motion commands should be suppressed until this is true.
   */
  virtual void readInputs(const ProcessImage& image, bool wkc_valid, bool operational) {
    (void)image;
    (void)wkc_valid;
    (void)operational;
  }

  /**
   * Prime output PDO bytes to safe values immediately before the bus enters SAFE_OP (outputs start
   * being transmitted). For example, a CiA402 profile writes a Shutdown controlword here so the
   * drive sees a valid initial state before the RT cycle starts. Called on the bring-up thread.
   * @param image Live PDO byte map; write safe initial output values into it.
   */
  virtual void primeOutputs(ProcessImage& image) { (void)image; }

  /* ---- Graceful shutdown coordination + fault/stop surfacing are inherited from
   * {@link IDeviceLifecycle}: prepareShutdown / readyForShutdown / requiresMotionShutdown /
   * hasLeftOperationEnabled / requiresAlShutdown / readyForAlShutdown / cyclicStopRequested /
   * cyclicStopReason / lastStatusWordForDiagnostics. Override the ones your device class needs. */

  /** End-of-run hook called after the RT thread has joined; safe to perform SDO reads.
   * @param svc Slave services handle available for post-run SDO reads (e.g. fault codes). */
  virtual void captureExitDiagnostics(ISlaveServices& svc) { (void)svc; }

  /**
   * @name Capability queries
   * Used by the facade layer to discover what typed interface this profile implements. A profile
   * returns a non-null pointer for each capability contract it satisfies. The default for all
   * three is null, meaning the profile exposes no typed facade capability.
   */
  ///@{
  /** Query whether this profile drives a motion (servo) axis.
   * @return A non-null `IMotionProfile*` if so (used to back an `Axis` facade handle),
   *         or null if this profile does not implement the motion contract. */
  virtual IMotionProfile* asMotion() noexcept { return nullptr; }
  /** Query whether this profile exposes digital/analog I/O channels.
   * @return A non-null `IIoProfile*` if so (used to back an `IoModule` facade handle),
   *         or null if this profile does not implement the I/O contract. */
  virtual IIoProfile* asIo() noexcept { return nullptr; }
  /** Query whether this profile exposes position/velocity encoder readings.
   * @return A non-null `IEncoderProfile*` if so (used to back an `Encoder` facade handle),
   *         or null if this profile does not implement the encoder contract. */
  virtual IEncoderProfile* asEncoder() noexcept { return nullptr; }
  ///@}
};

}  // namespace ecdev
