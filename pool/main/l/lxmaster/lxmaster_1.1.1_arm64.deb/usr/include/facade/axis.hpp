#pragma once

#include "devices/motion_profile.hpp"
#include "facade/device_facade.hpp"

#include <cstdint>
#include <string>

namespace ecfacade {

/**
 * High-level motion handle a PLC/application programmer uses, analogous to a TwinCAT "NC axis".
 *
 * An `Axis` is a thin, safe wrapper over an {@link ecdev::IMotionProfile}. The application never
 * sees CiA402 controlwords, PDO offsets, the ENI, or the backend: it commands positions and reads back
 * status in engineering-relevant terms. The same `Axis` works for any drive family whose profile
 * implements `IMotionProfile`, so swapping a CiA402 servo for a different drive class does not
 * change application code.
 *
 * All methods are safe to call from the application thread while the RT cycle runs (the backing
 * profile uses lock-free state). Exception: `setDriveMode()` and the inherited `configure()` must
 * only be called between `EcNetwork::prepare()` and `EcNetwork::start()`.
 */
class Axis : public DeviceFacade {
public:
  Axis(ecdev::IMotionProfile* motion, std::string name, ecdev::IEthercatDevice* device);

  /** Select the cyclic operating mode (CSP / CSV / CST) this axis runs; the CiA402 profile writes
   *  0x6060 to match. Call before start() to choose the initial mode, or while running to switch
   *  live -- a live switch takes effect only when the ENI maps 0x6060 into the RxPDO (eni_gen does
   *  this for CiA402 drives). RT-safe.
   * @param mode The desired operating mode (`DriveOpMode::Csp`, `Csv`, or `Cst`). */
  void setDriveMode(ecdev::DriveOpMode mode) noexcept;

  /* ---- Commands ---- */
  /** Command an absolute target position (CSP). Implicitly exits "hold actual" mode.
   * @param counts Target position in encoder counts (CiA402 0x607A). */
  void moveTo(std::int32_t counts) noexcept;
  /** Command a target velocity (CSV). Only has effect while the drive runs in CSV mode.
   * @param counts_per_sec Target velocity in encoder counts per second (CiA402 0x60FF). */
  void moveAtVelocity(std::int32_t counts_per_sec) noexcept;
  /** Command a target torque (CST). Only has effect while the drive runs in CST mode.
   * @param per_mille_rated Target torque in per-mille of rated torque (CiA402 0x6071). */
  void applyTorque(std::int32_t per_mille_rated) noexcept;
  /** Request the drive to power up and hold position. */
  void enable() noexcept;
  /** Request the drive to power down to a de-energised resting state. */
  void disable() noexcept;
  /** Clear a latched drive fault (one-shot). */
  void resetFault() noexcept;

  /* ---- Status ---- */
  /** Actual position reported by the drive (encoder counts, CiA402 0x6064). RT-safe. */
  std::int32_t actualPosition() const noexcept;
  /** Last target position sent to the drive (encoder counts). Matches the most recent `moveTo()`
   *  argument, or the actual position at enable time when in "hold actual" mode. RT-safe. */
  std::int32_t commandedPosition() const noexcept;
  /** Actual velocity reported by the drive (encoder counts/s, CiA402 0x606C). 0 if the drive
   *  does not map this object. RT-safe. */
  std::int32_t actualVelocity() const noexcept;
  /** True when the DS402 state machine has reached Operation Enabled. RT-safe. */
  bool isEnabled() const noexcept;
  /** True when the drive reports a latched fault (DS402 Fault state, statusword bit 3). Call
   *  `resetFault()` to clear. RT-safe. */
  bool isFaulted() const noexcept;
  /** Raw DS402 statusword (CiA402 0x6041). Useful for advanced diagnostics or for drives that
   *  expose manufacturer-specific bits beyond what `isEnabled()` / `isFaulted()` cover. RT-safe. */
  std::uint16_t statusword() const noexcept;
  /** Drive-reported actual torque (0x6077, per-mille of rated); 0 if the profile doesn't map it. */
  std::int32_t actualTorque() const noexcept;
  /** Drive-reported modes-of-operation display (0x6061; 8=CSP, 9=CSV, 10=CST); 0 if unmapped. */
  std::int32_t modeDisplay() const noexcept;

  /** Escape hatch for advanced callers that need the underlying motion contract.
   * @return The `IMotionProfile` backing this axis. Never null while the axis is valid. */
  ecdev::IMotionProfile* motionProfile() const noexcept;

private:
  ecdev::IMotionProfile* motion_;
};

}  // namespace ecfacade
