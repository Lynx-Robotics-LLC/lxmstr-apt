#pragma once

#include "devices/io_profile.hpp"
#include "facade/device_facade.hpp"

#include <cstddef>
#include <cstdint>
#include <string>

namespace ecfacade {

/**
 * High-level digital/analog I/O handle. Thin wrapper over an {@link ecdev::IIoProfile}; the
 * application reads/writes named-by-index channels without seeing CoE objects, PDO offsets, or
 * the backend. Safe to use from the application thread during the RT cycle.
 */
class IoModule : public DeviceFacade {
public:
  IoModule(ecdev::IIoProfile* io, std::string name, ecdev::IEthercatDevice* device);

  /** Number of digital input channels available on this module (process-image order).
   * @return Channel count; use as the exclusive upper bound for `readDigital()`. */
  std::size_t digitalInputCount() const noexcept;
  /** Number of digital output channels available on this module (process-image order).
   * @return Channel count; use as the exclusive upper bound for `writeDigital()`. */
  std::size_t digitalOutputCount() const noexcept;
  /** Number of analog input channels available on this module.
   * @return Channel count; use as the exclusive upper bound for `readAnalog()`. */
  std::size_t analogInputCount() const noexcept;
  /** Number of analog output channels available on this module.
   * @return Channel count; use as the exclusive upper bound for `writeAnalog()`. */
  std::size_t analogOutputCount() const noexcept;

  /** Read the current state of a digital input channel. RT-safe.
   * @param channel 0-based channel index.
   * @return The input state, or `false` for out-of-range channels. */
  bool readDigital(std::size_t channel) const noexcept;
  /** Read back the last value written to a digital output channel. RT-safe.
   * @param channel 0-based channel index.
   * @return The last commanded output state, or `false` for out-of-range channels. */
  bool digitalOutputState(std::size_t channel) const noexcept;
  /** Command a digital output channel. Out-of-range channels are silently ignored. RT-safe.
   * @param channel 0-based channel index.
   * @param value `true` to assert the output, `false` to de-assert it. */
  void writeDigital(std::size_t channel, bool value) noexcept;

  /** Read the current value of an analog input channel (raw counts). RT-safe.
   * @param channel 0-based channel index.
   * @return The raw input value, or `0` for out-of-range channels. */
  std::int32_t readAnalog(std::size_t channel) const noexcept;
  /** Read back the last value written to an analog output channel (raw counts). RT-safe.
   * @param channel 0-based channel index.
   * @return The last commanded output value, or `0` for out-of-range channels. */
  std::int32_t analogOutputState(std::size_t channel) const noexcept;
  /** Command an analog output channel (raw counts). Out-of-range channels are silently
   *  ignored. RT-safe.
   * @param channel 0-based channel index.
   * @param value Raw output value in process-image counts. */
  void writeAnalog(std::size_t channel, std::int32_t value) noexcept;

  /** Escape hatch to the underlying I/O profile contract for callers that need capabilities
   *  beyond the standard channel accessors.
   * @return The `IIoProfile` backing this module. Never null while the module is valid. */
  ecdev::IIoProfile* ioProfile() const noexcept;

private:
  ecdev::IIoProfile* io_;
};

}  // namespace ecfacade
