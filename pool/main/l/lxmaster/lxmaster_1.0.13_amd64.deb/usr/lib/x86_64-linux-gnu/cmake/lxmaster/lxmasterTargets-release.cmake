#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "lxmaster::lxmaster" for configuration "Release"
set_property(TARGET lxmaster::lxmaster APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(lxmaster::lxmaster PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/liblxmaster.so.1.0.13"
  IMPORTED_SONAME_RELEASE "liblxmaster.so.1"
  )

list(APPEND _cmake_import_check_targets lxmaster::lxmaster )
list(APPEND _cmake_import_check_files_for_lxmaster::lxmaster "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/liblxmaster.so.1.0.13" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
