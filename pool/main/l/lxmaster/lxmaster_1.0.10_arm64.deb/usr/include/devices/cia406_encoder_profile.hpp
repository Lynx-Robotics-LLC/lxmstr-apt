#pragma once

#include "devices/device_profile.hpp"
#include "devices/encoder_profile.hpp"
#include "devices/process_image.hpp"

#include <atomic>
#include <cstdint>
#include <memory>

namespace ecdev {

struct ProfileSelectionInput;

/** Build a CiA406EncoderProfile. Bind it to a device identity with `makeIdentityProfileFactory`. */
std::unique_ptr<IDeviceProfile> makeCiA406EncoderProfile(const ProfileSelectionInput& in);

/**
 * CiA 406 (encoder) profile. Reads the position value (0x6004) and optional velocity/status into a
 * lock-free snapshot exposed via {@link IEncoderProfile} (wrapped by the `Encoder` facade). A
 * read-only device class -- another data point that the plugin model is not motion-specific.
 */
class CiA406EncoderProfile final : public IDeviceProfile, public IEncoderProfile {
public:
  const char* profileName() const override { return "CiA406-encoder"; }
  IEncoderProfile* asEncoder() noexcept override { return this; }

  std::string configurePreOp(ISlaveServices& svc, ProcessImage& image) override;
  void readInputs(const ProcessImage& image, bool wkc_valid, bool operational) override;

  std::int32_t position() const noexcept override {
    return position_.load(std::memory_order_acquire);
  }
  std::int32_t velocity() const noexcept override {
    return velocity_.load(std::memory_order_acquire);
  }
  std::uint16_t status() const noexcept override { return status_.load(std::memory_order_acquire); }

private:
  PdoEntryRef pos_ref_{};
  PdoEntryRef vel_ref_{};
  PdoEntryRef status_ref_{};
  std::atomic<std::int32_t> position_{0};
  std::atomic<std::int32_t> velocity_{0};
  std::atomic<std::uint16_t> status_{0};
};

}  // namespace ecdev
