#pragma once

#include "devices/cia402_fsm.hpp"
#include "devices/device_profile.hpp"
#include "devices/motion_profile.hpp"
#include "devices/process_image.hpp"
#include "devices/sync_mode.hpp"

#include <atomic>
#include <cstdint>
#include <memory>
#include <string>

namespace ecdev {

struct ProfileSelectionInput;

/** Build a CiA402DriveProfile from the selection input (op-mode / fault-policy flags). Bind it to a
 *  device identity with `makeIdentityProfileFactory`. */
std::unique_ptr<IDeviceProfile> makeCiA402DriveProfile(const ProfileSelectionInput& in);

/**
 * CiA 402 (CANopen-over-EtherCAT) servo-drive profile. Plugs onto a {@link GenericEniDevice} and
 * provides the drive-class behaviour that used to live in `CiA402Device`:
 *   - PreOP validation + operating-mode setup: it confirms the cyclic objects it drives
 *     (controlword/statusword/target+actual position) are present in the ENI PDO mapping and fails
 *     otherwise. It makes NO configuration assumptions ("ENI is law") with ONE deliberate
 *     exception: the operating mode 0x6060, which is application/axis intent rather than bus wiring,
 *     so the profile writes it (from `Config::op_mode`) and reads it back to confirm at PreOP. SM
 *     sync-mode (0x1C32/0x1C33), the 0x60C2 interpolation time, and any vendor tuning still arrive
 *     as ENI CoE InitCmds replayed by {@link GenericEniDevice}; DC SYNC0 is activated by the master
 *     from the ENI <DC>; the generic 0x1C1x/0x16xx PDO assignment is done by {@link GenericEniDevice}.
 *   - DS402 controlword state machine ({@link CiA402Fsm}) on the RT cyclic path.
 *   - A lock-free snapshot so application threads (through the `Axis` facade / IMotionProfile)
 *     read position/statusword and command targets without touching PDO bytes.
 *
 * It implements {@link IMotionProfile}, which is the only thing the `Axis` facade depends on, so
 * the controlword/statusword stay hidden inside this profile.
 */
class CiA402DriveProfile final : public IDeviceProfile, public IMotionProfile {
public:
  /** Cyclic operation mode this profile drives. CSP commands target position (0x607A); CSV
   * commands target velocity (0x60FF); CST commands target torque (0x6071, INT16). The ENI/ESI
   * must map the matching object and set the drive's modes-of-operation (0x6060) accordingly --
   * the profile only validates the mapping. The per-mode cyclic facts live in the OpModeTraits
   * table in cia402_drive_profile.cpp. */
  using OpMode = DriveOpMode;

  struct Config {
    bool enable_fsm{true};
    bool hold_actual_position{true};
    bool auto_fault_reset_and_recover{false};
    /** When a drive boots into OPERATIONAL already faulted (a residual fault from a prior run,
     * before it has ever reached Operation Enabled this run), automatically pulse a bounded
     * fault-reset and continue enabling instead of latching a terminal stop. A fault that appears
     * after the drive was successfully enabled (genuine mid-run trip) is always terminal. */
    bool startup_fault_autoreset{true};
    bool shutdown_require_switch_on_disabled{true};
    int fault_reset_arm_cycles{50};
    OpMode op_mode{OpMode::Csp};
  };

  explicit CiA402DriveProfile(Config cfg);

  const char* profileName() const override { return "CiA402-drive"; }
  IMotionProfile* asMotion() noexcept override { return this; }

  /* ---- IDeviceProfile ---- */
  std::string configurePreOp(ISlaveServices& svc, ProcessImage& image) override;
  std::string prepareSafeOp(ISlaveServices& svc, ProcessImage& image) override;
  void writeOutputs(ProcessImage& image, std::uint64_t cycle_count) override;
  void readInputs(const ProcessImage& image, bool wkc_valid, bool operational) override;
  void primeOutputs(ProcessImage& image) override;
  void prepareShutdown() override { out_.request_disable.store(true, std::memory_order_release); }
  bool readyForShutdown() const noexcept override { return isShutdownRestingState(); }
  bool requiresMotionShutdown() const noexcept override { return cfg_.enable_fsm; }
  bool requiresAlShutdown() const noexcept override {
    return cfg_.enable_fsm && cfg_.shutdown_require_switch_on_disabled;
  }
  bool hasLeftOperationEnabled() const noexcept override;
  bool readyForAlShutdown() const noexcept override;
  bool cyclicStopRequested() const noexcept override {
    return cyclic_stop_requested_.load(std::memory_order_acquire);
  }
  std::string cyclicStopReason() const override { return cyclic_stop_reason_; }
  std::uint16_t lastStatusWordForDiagnostics() const noexcept override { return statusword(); }
  void captureExitDiagnostics(ISlaveServices& svc) override;

  /* ---- IMotionProfile mode + fault configuration ---- */
  /** Choose the operating mode. Pre-start this seeds the initial mode; while running it also
   * switches live -- when the ENI maps 0x6060 into the RxPDO the profile writes out_.desired_mode
   * every cycle, so CSP/CSV/CST switch while OPERATIONAL. The atomic store is RT-safe; cfg_.op_mode
   * (used only by the legacy no-0x6060 path, which is fixed at PRE_OP) is not read cyclically in
   * PDO mode. */
  void setOperatingMode(DriveOpMode mode) noexcept override {
    cfg_.op_mode = mode;
    out_.desired_mode.store(mode, std::memory_order_release);
  }
  void setAutoFaultRecover(bool enable) noexcept override {
    cfg_.auto_fault_reset_and_recover = enable;
  }

  /* ---- IMotionProfile (application-thread API behind the Axis facade) ---- */
  void setTargetPosition(std::int32_t counts) noexcept override {
    out_.target_position.store(counts, std::memory_order_release);
    out_.have_target_position.store(true, std::memory_order_release);
  }
  /** CSV target velocity in counts/s. Has its own command slot (0x60FF) so a CSP position target
   * and a CSV velocity target can coexist for bumpless live mode switching; only the object
   * matching the active op-mode is honoured by the drive. */
  void setTargetVelocity(std::int32_t counts_per_sec) noexcept override {
    out_.target_velocity.store(counts_per_sec, std::memory_order_release);
  }
  /** CST target torque in per-mille of rated torque. Has its own command slot (0x6071) so it can
   * coexist with position/velocity targets for bumpless live mode switching; only the object
   * matching the active op-mode is honoured by the drive. */
  void setTargetTorque(std::int32_t per_mille_rated) noexcept override {
    out_.target_torque.store(per_mille_rated, std::memory_order_release);
  }
  void requestEnable() noexcept override {
    out_.request_disable.store(false, std::memory_order_release);
  }
  void requestDisable() noexcept override {
    out_.request_disable.store(true, std::memory_order_release);
  }
  void requestFaultReset() noexcept override {
    out_.request_fault_reset.store(true, std::memory_order_release);
  }
  std::int32_t actualPosition() const noexcept override {
    return in_.actual_position.load(std::memory_order_acquire);
  }
  std::int32_t targetPosition() const noexcept override {
    return out_.target_position.load(std::memory_order_acquire);
  }
  std::int32_t actualVelocity() const noexcept override {
    return in_.actual_velocity.load(std::memory_order_acquire);
  }
  std::int32_t actualTorque() const noexcept override {
    return in_.actual_torque.load(std::memory_order_acquire);
  }
  std::int32_t modeDisplay() const noexcept override {
    return in_.mode_display.load(std::memory_order_acquire);
  }
  std::uint16_t statusword() const noexcept override {
    return in_.statusword.load(std::memory_order_acquire);
  }
  bool isOperationEnabled() const noexcept override {
    return (statusword() & CiA402Fsm::kStateMask) == CiA402Fsm::kStateOperationEnabled;
  }
  bool isFault() const noexcept override {
    return (statusword() & CiA402Fsm::kStatusFaultBit) != 0;
  }

private:
  bool isShutdownRestingState() const noexcept {
    const std::uint16_t st = statusword() & CiA402Fsm::kStateMask;
    return st == CiA402Fsm::kStateReadyToSwitchOn || st == CiA402Fsm::kStateSwitchOnDisabled ||
           isFault();
  }

  Config cfg_;
  CiA402Fsm fsm_;

  /* Resolved process-image handles (set in configurePreOp / first cycle). */
  PdoEntryRef cw_ref_{};
  PdoEntryRef sw_ref_{};
  /** The single cyclic target object for the active op-mode (0x607A / 0x60FF / 0x6071), chosen
   * from the OpModeTraits table at resolve time. Used only on the legacy (no 0x6060 in PDO) path. */
  PdoEntryRef target_ref_{};
  /** Modes of operation (0x6060) in the RxPDO. When valid the profile is in "PDO mode control":
   * it writes the desired mode every cycle and can switch CSP/CSV/CST live. When invalid it falls
   * back to the legacy single-target path with the mode set once via SDO at PRE_OP. */
  PdoEntryRef mode_ref_{};
  /** Per-mode command targets, resolved independently so all three can be written each cycle (the
   * active one carries the command, the others a neutral value) for bumpless live switching. */
  PdoEntryRef target_pos_ref_{};
  PdoEntryRef target_vel_ref_{};
  PdoEntryRef target_torque_ref_{};
  PdoEntryRef actual_pos_ref_{};
  PdoEntryRef actual_vel_ref_{};
  PdoEntryRef actual_torque_ref_{};
  PdoEntryRef mode_display_ref_{};
  bool refs_resolved_{false};

  std::atomic<bool> cyclic_stop_requested_{false};
  std::string cyclic_stop_reason_;
  bool motion_fault_latched_{false};
  /* Startup fault-reset window state (see Config::startup_fault_autoreset). `ever_operation_enabled_`
   * flips true the first time the drive reaches Operation Enabled this run; after that any fault is a
   * terminal mid-run trip. `startup_reset_cycles_` bounds the pre-enable reset window;
   * `startup_reset_active_` is set by readInputs and consumed by writeOutputs to pulse bit 7. */
  bool ever_operation_enabled_{false};
  int startup_reset_cycles_{0};
  bool startup_reset_active_{false};

  struct alignas(64) InputSnapshot {
    std::atomic<std::int32_t> actual_position{0};
    std::atomic<std::int32_t> actual_velocity{0};
    std::atomic<std::int32_t> actual_torque{0};
    std::atomic<std::int32_t> mode_display{0};
    std::atomic<std::uint16_t> statusword{0};
  };
  struct alignas(64) OutputSnapshot {
    std::atomic<std::int32_t> target_position{0};
    std::atomic<std::int32_t> target_velocity{0};
    std::atomic<std::int32_t> target_torque{0};
    std::atomic<bool> have_target_position{false};
    std::atomic<bool> request_disable{false};
    std::atomic<bool> request_fault_reset{false};
    /** Live operating-mode request (PDO mode control). Seeded from Config::op_mode in the ctor. */
    std::atomic<DriveOpMode> desired_mode{DriveOpMode::Csp};
  };
  InputSnapshot in_;
  OutputSnapshot out_;

  void resolveRefs(const ProcessImage& image);
};

}  // namespace ecdev
