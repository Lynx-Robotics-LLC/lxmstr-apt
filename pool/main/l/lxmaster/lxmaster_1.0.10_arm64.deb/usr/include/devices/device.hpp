#pragma once

#include "ecmaster/slave_handler.hpp"

#include <cstddef>
#include <cstdint>
#include <memory>
#include <ostream>
#include <string>

namespace ecdev {

class Logger;  // forward declaration; defined in log.hpp

/**
 * Identity + placement of one EtherCAT slave on the bus. Filled in when binding the
 * discovered slave list to concrete device instances.
 */
struct DeviceInfo {
  std::uint32_t vendor_id{0};
  std::uint32_t product_id{0};
  std::uint32_t revision{0};
  std::uint16_t slave_index{0};
  const char*   display_name{""};
};

/**
 * Maximum EtherCAT state machine (ESM) level a device should be walked to during bring-up.
 * PRE_OP is the floor every device must reach for CoE/PDO configuration, so it is the default and
 * the lowest meaningful ceiling; the value only gates whether bring-up continues to SAFE_OP and OP.
 */
enum class BringupState { PreOp, SafeOp, Op };

/**
 * Cycle-time PDO window into a slave's process-data region. Devices read inputs and write outputs
 * through this view; the underlying memory is owned by SOEM's IOmap.
 */
struct PdoView {
  std::uint8_t*       outputs{nullptr};
  std::size_t         output_bytes{0};
  const std::uint8_t* inputs{nullptr};
  std::size_t         input_bytes{0};
};

/**
 * Generic vendor-neutral EtherCAT device abstraction. The orchestration layer (`ecnet`) interacts
 * with every slave exclusively through this interface. There is one concrete implementation,
 * {@link GenericEniDevice}; device-class behaviour (CiA 402 drive, CiA 401 I/O, ...) is supplied by
 * an {@link IDeviceProfile} plugged into it rather than by subclassing this interface.
 *
 * Why two interfaces (`IEthercatDevice` vs `IDeviceProfile`)? They look similar because
 * `GenericEniDevice` forwards most calls to its profile, but they are deliberately separate:
 *   - `IEthercatDevice` is the stable boundary `ecnet` depends on (it owns the ENI-driven process
 *     image and PDO binding, and works even for *passive* slaves that have no profile).
 *   - `IDeviceProfile` is the device-class plug-in, written against the narrow `ISlaveServices` /
 *     `ProcessImage` contracts with no knowledge of SOEM or the master.
 * Keeping them apart lets a new device class be added by writing a profile, without touching the
 * orchestration layer or the generic device.
 */
class IEthercatDevice {
public:
  virtual ~IEthercatDevice() = default;

  virtual const DeviceInfo& info() const = 0;

  /**
   * Maximum ESM state this device should be walked to during bring-up. Library-internal: the
   * application sets it indirectly via the facade `configure()` overloads, never by calling these
   * directly. Defaults to `BringupState::PreOp` (the device is configured but not driven to OP
   * unless explicitly opted in).
   */
  virtual void setMaxBringupState(BringupState state) = 0;
  virtual BringupState maxBringupState() const = 0;

  /** Called from `ecmaster::ISlaveHandler::onPrepareToMap` while the slave is in PreOP. */
  virtual int configurePreOp(ecmaster::SlaveContext& ctx) = 0;

  /** Optional: one-time preparation after SAFE_OP is reached and cyclic PDO is running. */
  virtual void prepareSafeOp(ecmaster::SlaveContext& ctx) { (void)ctx; }

  /**
   * Optional: signal that the device should start releasing its actuator *while PDO is still
   * flowing* (RT thread still running). CiA402 drives override this to request the DS402 FSM
   * to walk toward `Switch On Disabled`, so the motor brake/torque is released gracefully
   * before the bus state is walked down. Default: no-op.
   */
  virtual void prepareShutdown() {}

  /**
   * Shutdown phase 2 gate: poll predicate indicating the device is safe to stop cycling. For
   * CiA402 drives this is "statusword reports Switch On Disabled (or Fault)". `EcNetwork::stop()`
   * waits up to a short deadline for every bound device to return true before stopping the
   * RT thread. Default: always ready (no-op devices are trivially safe).
   */
  virtual bool readyForShutdown() const noexcept { return true; }

  /**
   * Per-cycle output producer. Runs before `sendProcessData`. Implementations should be
   * branch-light and do NO mailbox SDO reads — the cycle budget on DC-strict drives is tight.
   */
  virtual void writeOutputs(PdoView& pdo, std::uint64_t cycle_count) = 0;

  /**
   * Per-cycle input consumer. Runs after `receiveProcessData`. `wkc_valid` is the per-group
   * working-counter check: when false the input buffer may be stale.
   */
  virtual void readInputs(const PdoView& pdo, bool wkc_valid, bool operational) = 0;

  /** When true, the RT cyclic thread should exit and surface `cyclicStopReason()`. */
  virtual bool cyclicStopRequested() const noexcept { return false; }

  /** Human-readable reason for `cyclicStopRequested()` (empty if not requested). */
  virtual std::string cyclicStopReason() const { return {}; }

  /**
   * Optional: called once by `EcNetwork::stop()` *after* the RT thread has been joined
   * but *before* the master socket is closed. This is the last moment a device can do
   * mailbox / SDO reads to capture vendor-specific diagnostics (CiA402 0x603F, drive-side
   * fault histories, temperatures, ...). The implementation should cache whatever it needs
   * so `reportExitStatus()` can print from memory — `reportExitStatus` runs *after* the
   * master is closed and can no longer issue SDO reads.
   */
  virtual void captureExitDiagnostics(ecmaster::SlaveContext& ctx) { (void)ctx; }

  /**
   * Debug-only (`NetworkConfig::debug`): one-shot CoE read of fault registers during AL
   * wind-down. Invoked from the RT thread at SAFE_OP transition milestones and from the main
   * thread after join — not during phase-locked OP cycling. Default: no-op.
   */
  virtual void debugShutdownFaultMilestone(ecmaster::SlaveContext& ctx, const char* label) {
    (void)ctx;
    (void)label;
  }

  /** Print device-specific summary at application exit (end-of-run status, last error, ...). */
  virtual void reportExitStatus(std::ostream& os) const { (void)os; }

  /**
   * Returns a non-empty reason if PreOP configuration (SDO writes, PDO remap, interpolation
   * time, vendor-specific SDOs) failed. `EcNetwork::start()` checks this on each bound device
   * between `configMap()` and the OP transition and aborts cleanly with a diagnostic message
   * rather than silently proceeding to fail in OP with a cryptic AL-status code.
   *
   * Empty string = no error. SOEM discards the `PO2SOconfig` return value, so we have to
   * carry the status out-of-band through this hook.
   */
  virtual std::string configureError() const { return {}; }

  /**
   * Returns a non-empty reason if `prepareSafeOp()` failed (e.g. vendor SDOs that must be
   * confirmed after PDO warmup). Checked by `EcNetwork::start()` before OP entry.
   */
  virtual std::string safeOpPrepareError() const { return {}; }

  /**
   * Attach a logger for device-side diagnostic messages (PreOP SDO wkc reports, SAFE_OP
   * fault-reset notice, etc.). Default implementation is a no-op. Concrete devices that want to
   * emit such messages override this. Setting a null logger must be safe.
   */
  virtual void setLogger(Logger* logger) { (void)logger; }

  /** Prime output PDO before SAFE_OP (e.g. CiA402 controlword → Shutdown). Default: no-op. */
  virtual void primeProcessOutputs(PdoView& pdo) { (void)pdo; }

  /*
   * Graceful shutdown runs as up to three ordered phases (driven by `EcNetwork`, logged as
   * S1/S2/S3); each phase polls its `*Requires*`/ready predicate across all bound devices:
   *
   *   Phase 1 (motion):  while PDO still flows, wait until each drive has left Operation Enabled.
   *                      Gated by `requiresMotionShutdown()` / `hasLeftOperationEnabled()`.
   *   Phase 2 (resting): wait until every device reports it is safe to stop cycling (the RT
   *                      thread then stops). Gated by `readyForShutdown()` (above).
   *   Phase 3 (AL gate): before walking the bus state down, wait until each device is safe for
   *                      that wind-down. Gated by `requiresAlShutdown()` / `readyForAlShutdown()`.
   *
   * Devices that do not opt into a phase (default predicates) trivially satisfy it.
   */

  /** Phase 1 applies to this device (it must leave Operation Enabled before cycling stops). */
  virtual bool requiresMotionShutdown() const noexcept { return false; }

  /** Phase 1 complete: the device has left Operation Enabled (or faulted). */
  virtual bool hasLeftOperationEnabled() const noexcept { return true; }

  /** Phase 3 applies to this device (it must reach a safe state before AL wind-down). */
  virtual bool requiresAlShutdown() const noexcept { return false; }

  /** Phase 3 complete: the device is safe for AL wind-down. Default: same gate as phase 2. */
  virtual bool readyForAlShutdown() const noexcept { return readyForShutdown(); }

  /** Optional statusword for shutdown debug logs. */
  virtual std::uint16_t lastStatusWordForDiagnostics() const noexcept { return 0; }
};

/**
 * Adapter that maps `IEthercatDevice` onto `ecmaster::ISlaveHandler` for SOEM PO2SO hooks.
 */
class DeviceSlaveHandler final : public ecmaster::ISlaveHandler {
public:
  explicit DeviceSlaveHandler(std::unique_ptr<IEthercatDevice> device);

  int onPrepareToMap(ecmaster::SlaveContext& ctx) override;

  IEthercatDevice* device() { return device_.get(); }
  const IEthercatDevice* device() const { return device_.get(); }

private:
  std::unique_ptr<IEthercatDevice> device_;
};

}  // namespace ecdev
