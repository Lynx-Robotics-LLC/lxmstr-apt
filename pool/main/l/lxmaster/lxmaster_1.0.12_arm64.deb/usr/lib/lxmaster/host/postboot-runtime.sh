#!/usr/bin/env bash
# LXMASTER per-boot RT tuning runtime (NIC IRQ affinity + ethtool + cpufreq + cpuidle).
#
# This is the executable copied to /usr/local/sbin/lxmaster-firm-rt-postboot by
# 'lxmaster host setup' and run at every boot by the lxmaster-firm-rt-postboot.service
# systemd unit. It applies kernel runtime state that does not survive reboot.
#
# It is silent on success (journald already records that the oneshot ran); only failures
# are logged. Install/uninstall + the systemd unit are owned by setup.sh / revert.sh.
#
# Environment (set in the unit's Environment= by setup.sh):
#   LXMASTER_RT_IFACE                    EtherCAT NIC name
#   LXMASTER_RT_CPU                      RT thread CPU index
#   LXMASTER_RT_MAX_CPUIDLE_LATENCY_US   Disable cpuidle states with exit latency > this us
#                                        on the RT CPU (default 5).

set -uo pipefail

SCRIPT_NAME=lxmaster-firm-rt-postboot
warn() { echo "$SCRIPT_NAME: warning: $*" >&2; }
have_cmd() { command -v "$1" >/dev/null 2>&1; }

policy_covers_cpu() {
  local rt=$1 cpus=$2
  [[ -z "$cpus" ]] && return 1
  [[ "$rt" =~ ^[0-9]+$ ]] || return 1
  local tok normalized=${cpus//,/ }
  for tok in $normalized; do
    [[ -z "$tok" ]] && continue
    if [[ "$tok" =~ ^([0-9]+)-([0-9]+)$ ]]; then
      (( rt >= ${BASH_REMATCH[1]} && rt <= ${BASH_REMATCH[2]} )) && return 0
    elif [[ "$tok" == "$rt" ]]; then
      return 0
    fi
  done
  return 1
}

ethtool_max_ring() {
  local iface=$1 dir=$2
  ethtool -g "$iface" 2>/dev/null | awk -v d="$dir:" '
    /^Pre-set maximums:/ { in_max = 1; next }
    /^Current hardware/  { in_max = 0 }
    in_max && $1 == d    { print $2 }' | head -1
}

list_irqs_for_iface() {
  local iface=$1 dev=/sys/class/net/$1/device
  [[ -e $dev ]] || return 0
  local sysfs_count=0 f
  if [[ -d $dev/msi_irqs ]]; then
    for f in "$dev"/msi_irqs/*; do [[ -e $f ]] || continue; basename "$f"; sysfs_count=$((sysfs_count+1)); done
  fi
  if [[ -d $dev/msix_irqs ]]; then
    for f in "$dev"/msix_irqs/*; do [[ -e $f ]] || continue; basename "$f"; sysfs_count=$((sysfs_count+1)); done
  fi
  if [[ $sysfs_count -eq 0 ]]; then
    local dt irq_lines
    dt=$(basename "$(readlink -f "$dev")")
    irq_lines=$(awk -v d="$dt" '$0 ~ d { gsub(":", "", $1); if ($1+0>0) print $1 }' /proc/interrupts 2>/dev/null | sort -u)
    [[ -z "$irq_lines" ]] && irq_lines=$(awk -v d="$iface" '$NF == d { gsub(":", "", $1); if ($1+0>0) print $1 }' /proc/interrupts 2>/dev/null | sort -u)
    [[ -n "$irq_lines" ]] && printf '%s\n' "$irq_lines"
  fi
}

apply_irq_affinity_nic() {
  local iface=$1 cpu=$2 irq applied=0
  [[ -n "$iface" && -n "$cpu" ]] || return 0
  [[ -d "/sys/class/net/$iface" ]] || { warn "NIC IRQ affinity: /sys/class/net/$iface missing"; return 0; }
  while IFS= read -r irq; do
    [[ -z "$irq" ]] && continue
    local path=/proc/irq/$irq/smp_affinity_list
    [[ -w "$path" ]] || { warn "IRQ $irq ($iface): cannot write $path"; continue; }
    if printf '%s\n' "$cpu" >"$path" 2>/dev/null; then
      applied=$((applied + 1))
    else
      warn "IRQ $irq ($iface): kernel rejected smp_affinity=$cpu"
    fi
  done < <(list_irqs_for_iface "$iface")
  [[ $applied -eq 0 ]] && warn "NIC IRQ affinity: no IRQs pinned for $iface."
}

cpufreq_sysfs_any() {
  shopt -s nullglob
  local p
  for p in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor \
           /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    [[ -e "$p" ]] && { shopt -u nullglob; return 0; }
  done
  shopt -u nullglob
  return 1
}

set_cpufreq_performance_for_cpu() {
  local rt_cpu=$1
  cpufreq_sysfs_any || return 0
  if have_cmd cpupower && cpupower -c "$rt_cpu" frequency-set -g performance >/dev/null 2>&1; then return 0; fi
  local govpath="/sys/devices/system/cpu/cpu${rt_cpu}/cpufreq/scaling_governor"
  [[ -w "$govpath" ]] && echo performance >"$govpath" 2>/dev/null && return 0
  local pol affpath cpus_line
  for pol in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
    [[ -e "$pol" ]] || continue
    affpath="$(dirname "$pol")/affected_cpus"; [[ -r "$affpath" ]] || continue
    cpus_line=$(tr -d '\n\r' <"$affpath")
    policy_covers_cpu "$rt_cpu" "$cpus_line" || continue
    echo performance >"$pol" 2>/dev/null && return 0
  done
  local g0=/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
  local gr=/sys/devices/system/cpu/cpu${rt_cpu}/cpufreq/scaling_governor
  if [[ -e "$g0" && ! -r "$gr" && "$rt_cpu" =~ ^[0-9]+$ && "$rt_cpu" != "0" ]]; then
    echo performance >"$g0" 2>/dev/null && return 0
  fi
  warn "could not set performance governor for cpu$rt_cpu."
}

disable_deep_cpuidle_for_cpu() {
  local rt_cpu=$1 max_us=${LXMASTER_RT_MAX_CPUIDLE_LATENCY_US:-5}
  local base="/sys/devices/system/cpu/cpu${rt_cpu}/cpuidle"
  [[ -d "$base" ]] || return 0
  shopt -s nullglob
  local sdir lat dis
  for sdir in "$base"/state*; do
    [[ -d "$sdir" ]] || continue
    lat=$(cat "$sdir/latency" 2>/dev/null || echo "0")
    dis=$(cat "$sdir/disable" 2>/dev/null || echo "0")
    if [[ "$lat" =~ ^[0-9]+$ ]] && (( lat > max_us )) && [[ "$dis" != "1" ]]; then
      echo 1 >"$sdir/disable" 2>/dev/null || warn "cpuidle: cpu$rt_cpu $(basename "$sdir") disable write failed"
    fi
  done
  shopt -u nullglob
}

apply_tunings() {
  local iface=$1 rt_cpu=$2
  if [[ -z "$iface" ]]; then
    warn "no iface set; skipping NIC tuning."
  elif ! have_cmd ethtool; then
    warn "ethtool not installed; skipping NIC tuning."
  elif [[ ! -d /sys/class/net/$iface ]]; then
    warn "interface '$iface' not present; skipping NIC tuning."
  else
    ethtool -C "$iface" rx-usecs 0 rx-frames 1 tx-usecs 0 tx-frames 1 adaptive-rx off adaptive-tx off 2>/dev/null || true
    ethtool -K "$iface" gso off tso off gro off lro off 2>/dev/null || true
    local rxmax txmax; rxmax=$(ethtool_max_ring "$iface" RX) || true; txmax=$(ethtool_max_ring "$iface" TX) || true
    [[ -n "$rxmax" && -n "$txmax" ]] && ethtool -G "$iface" rx "$rxmax" tx "$txmax" 2>/dev/null || true
    ethtool --set-eee "$iface" eee off 2>/dev/null || true
    ethtool -s "$iface" wol d 2>/dev/null || true
  fi

  apply_irq_affinity_nic "$iface" "$rt_cpu"

  if [[ -n "$rt_cpu" ]]; then
    set_cpufreq_performance_for_cpu "$rt_cpu"
    disable_deep_cpuidle_for_cpu "$rt_cpu"
  else
    warn "LXMASTER_RT_CPU unset; skipping cpufreq/cpuidle."
  fi
}

apply_tunings "${LXMASTER_RT_IFACE:-}" "${LXMASTER_RT_CPU:-}"
