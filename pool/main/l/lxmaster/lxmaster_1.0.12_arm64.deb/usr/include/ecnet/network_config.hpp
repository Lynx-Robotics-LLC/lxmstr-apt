#pragma once

#include "devices/log.hpp"
#include "devices/profile_registry.hpp"
#include "devices/sync_mode.hpp"

#include "ecmaster/ec_master.hpp"
#include "ecnet/bus_fault.hpp"

#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <vector>

namespace ecnet {

/** Re-exported here so callers only need `ecnet/network_config.hpp`. */
using SyncMode = ecdev::SyncMode;

/** Pass to `DcConfig::dc_sync_busy_wait_ns` to use `bus.cycle_ns / 4`. */
static constexpr std::int32_t kDcSyncBusyWaitAuto = -1;

struct BusConfig {
  std::string ifname;
  /** Cyclic period in ns. 0 = unset until the ENI is loaded; `EcNetwork` adopts the ENI's
   *  `<Config><Cyclic><CycleTime>` as the single source of truth. There is no CLI/code override. */
  std::uint32_t cycle_ns{0};
  /** Resolved output, not an input: `EcNetwork::loadAndValidateEni` sets this from the ENI
   *  (DcSync0 when the bus carries a SYNC0 device, else SmEvent). The app does not choose it. */
  SyncMode sync_mode{SyncMode::DcSync0};
};

struct DcConfig {
  /** DC + SYNC0 enablement. Not user policy: `EcNetwork::loadAndValidateEni` derives both from
   *  whether the ENI carries a per-slave <DC> block, so the ENI is the source of truth. The SYNC0
   *  period and shift likewise come from each slave's <DC> (CycleTime0 / ShiftTime), not from any
   *  code-side knob. */
  bool use_dc{true};
  bool use_sync0{true};
  bool ec_sync_to_dc{true};
  std::int32_t dc_sync_kp_div{3};
  std::int32_t dc_sync_ki_div{20};
  std::int32_t dc_sync_busy_wait_ns{kDcSyncBusyWaitAuto};
  bool sync_trace_include_warmup{false};
  int dc_lock_warmup_cycles{200};
  std::uint32_t dc_diff_op_gate_max_ns{10'000};
  int dc_diff_op_gate_stable_cycles{40};
  int dc_diff_op_gate_timeout_cycles{2'000};
};

struct RtConfig {
  bool enable_rt_scheduling{true};
  int rt_priority{49};
  int cpu_affinity{-1};
};

/**
 * Runtime logging configuration. A single gate (`enabled`) replaces the old `debug`/`diagnostics`
 * pair; severity and subsystem are selected by `min_level` / `category_mask`. The compile-time
 * `LXMASTER_ENABLE_DEBUG` (`ecdev::kDebugEnabled`) still strips the verbose `Info`/`Debug`/`Trace`
 * call sites from a release binary; `Error`/`Warn` remain. With `enabled == false` nothing is
 * logged (default), preserving the historically quiet runtime.
 */
struct DebugConfig {
  bool enabled{false};
  ecdev::LogLevel min_level{ecdev::LogLevel::Info};
  std::uint32_t category_mask{ecdev::kLogCatAll};
  /** Empty => ConsoleSink (cerr for Error/Warn, cout otherwise); non-empty => rotating FileSink. */
  std::string log_file;
  /** Debug ring capacity (process-data snapshots) for the RT->worker hand-off. Power of two; 0 =>
   *  built-in default. Larger gives high-rate Trace logging more headroom before drops. */
  std::size_t debug_ring_capacity{0};
  std::size_t sync_trace_capacity{0};
  std::uint32_t sync_trace_window_ns{0};
};

struct ShutdownConfig {
  int device_timeout_ms{500};
  int al_gate_timeout_ms{2000};
  int post_sod_settle_ms{200};
  int safeop_timeout_ms{2000};
  int al_state_timeout_ms{2000};
};

/**
 * ENI-driven configuration. EcNetwork loads `eni_path` (required), validates it against the
 * project-bundled ETG.2100 schema (embedded — there is no user-supplied XSD), verifies it
 * matches the scanned hardware, and auto-creates one generic CiA402 device per ENI <Slave>.
 * ENI is the only setup mode: there is no code-first / hard-coded device path.
 *
 * Per-axis settings are applied after prepare() returns by iterating net.axes(): call
 * Axis::setDriveMode(op_mode) to pick CSP/CSV/CST and Axis::configure() to walk the axis to OP.
 */
struct EniConfig {
  std::string eni_path;
};

/**
 * User-facing configuration for an EcNetwork. Bus timing, DC, RT scheduling, and shutdown
 * policy live here; drive-specific PDO/FSM options live on `CiA402Config` / vendor configs.
 *
 * Tuning guidance: `docs/dc_sync_tuning.md`. Deployment RT overrides: `scripts/rt/README.md`.
 */
struct NetworkConfig {
  static constexpr std::int32_t kDcSyncBusyWaitAuto = ecnet::kDcSyncBusyWaitAuto;

  BusConfig bus;
  DcConfig dc;
  RtConfig rt;
  DebugConfig debug;
  ShutdownConfig shutdown;
  EniConfig eni;
  /** Backend protocol timeouts / retries (microseconds). Defaults from the backend baseline;
   *  overridable via `LXMASTER_TIMEOUT_*` / `LXMASTER_RETRIES`. Pushed to the backend before `init()`
   *  (honored on a best-effort basis depending on the active backend). */
  ecmaster::Timeouts timeouts;
  int watchdog_low_wkc_cycles{100};
  int op_entry_cooldown_cycles{8};

  /**
   * Optional bus-fault notification. Invoked exactly once when the cycle-health watchdog trips
   * (a slave dropped out / cable unplugged / frames corrupted), carrying a structured `BusFault`
   * that pinpoints the break (upstream slave + ESC port) and lists the slaves that went silent.
   *
   * Delivery: called on a detached helper thread (NOT the RT cyclic thread), so the handler may
   * do non-RT work and may safely call `EcNetwork::stop()`. Because it runs detached, anything the
   * handler captures by reference must outlive the network. Leave empty to opt out; lxmaster still
   * renders the fault in `lastError()` / `reportDeviceStatus()`.
   */
  std::function<void(const BusFault&)> on_bus_fault;

  /**
   * App-supplied device classes, considered ahead of the self-registered built-ins when classifying
   * each ENI slave (see `ecdev::ProfileRegistry::select`). Use this to bind a device identity for a
   * single run without static registration -- e.g.
   * `cfg.extra_profile_factories.push_back(ecdev::makeIdentityProfileFactory({vendor, product},
   * makeMyProfile, "my-device"));`. `shared_ptr` keeps `NetworkConfig` copyable. The durable path
   * for a new device is still a self-registering file (LXMASTER_REGISTER_DEVICE).
   */
  std::vector<std::shared_ptr<ecdev::IProfileFactory>> extra_profile_factories;

  /** Network defaults (DC-sync PI kp_div=3, ki_div=20). The cyclic period is
   *  left unset (`bus.cycle_ns == 0`) and the sync mode is decided by the ENI in
   *  `EcNetwork::loadAndValidateEni`; the PI tuning here is inert when the ENI resolves to the SM
   *  event. There is no app-layer DC-vs-SM choice.
   *
   *  Host-side params are read here from the per-host `LXMASTER_*` environment (published by
   *  `/etc/profile.d/lxmaster-config.sh`; see `scripts/rt/README.md`), so the
   *  effective precedence is built-in default < ENV. The set covers the DC-sync
   *  PI knobs (kp_div, ki_div, dc_sync_busy_wait_ns, dc_lock_warmup_cycles, ec_sync_to_dc), the
   *  OP-entry DC gate (dc_diff_op_gate_max_ns / _stable_cycles / _timeout_cycles) and
   *  op_entry_cooldown_cycles, the RT scheduling identity (rt.cpu_affinity, rt.rt_priority,
   *  rt.enable_rt_scheduling), the EtherCAT interface name (`LXMASTER_RT_IFACE` -> `bus.ifname`), and
   *  the backend protocol timeouts/retries (`LXMASTER_TIMEOUT_*` / `LXMASTER_RETRIES` -> `timeouts.*`).
   *  Missing vars warn once and keep the built-in default (RT_ENABLE and the timeout knobs are
   *  silent opt-outs). */
  static NetworkConfig defaults();
};

enum class SyncTracePhase : std::uint8_t {
  Warmup = 0,
  DcGate = 1,
  Cooldown = 2,
  Operational = 3,
  Shutdown = 4,
};

struct SyncTraceSample {
  std::uint64_t rt_cycle{0};
  std::uint64_t operational_cycle_seq{0};
  std::int64_t dc_delta_ns{0};
  std::int64_t jitter_err_ns{0};
  std::int64_t dc_reftime_ns{0};
  std::int64_t expected_dc_reftime_ns{0};
  std::int64_t integral_ns{0};
  std::int64_t toff_ns{0};
  SyncTracePhase phase{SyncTracePhase::Operational};
};

}  // namespace ecnet
