#pragma once

#include <string>
#include <vector>

namespace ecnet {

/**
 * One slave that stopped responding when the bus fault was diagnosed.
 * `index` is the 1-based bus position; `name` is the SII/ENI device name.
 */
struct LostSlave {
  int index{0};
  std::string name;
};

/**
 * Structured description of a cyclic-bus fault, built when the cycle-health watchdog trips
 * (see `NetworkConfig::watchdog_low_wkc_cycles`). Delivered to the
 * application through the optional `NetworkConfig::on_bus_fault` callback and also used by
 * lxmaster to render the default `lastError()` / `reportDeviceStatus()` text.
 *
 * The break point is reconstructed from the standard DL-status register (0x0110): the
 * still-responding slave whose previously-active port lost its link is the upstream side of
 * the cable break, and `lost_slaves` are the devices that went silent behind it.
 */
struct BusFault {
  /** True when a fault was detected and this struct is meaningful. */
  bool occurred{false};
  /** 1-based bus index of the still-responding slave whose downstream port dropped its link.
   *  0 means no responder showed a dropped port (break at the master / first link). */
  int break_slave{0};
  /** SII/ENI name of `break_slave` (empty when `break_slave == 0`). */
  std::string break_slave_name;
  /** ESC port index (0-3) on `break_slave` whose link dropped, or -1 if unknown. */
  int break_port{-1};
  /** Slaves that stopped responding (downstream of the break). */
  std::vector<LostSlave> lost_slaves;
  /** Work counter observed on the tripping cycle and the expected value. */
  int wkc{0};
  int expected_wkc{0};
  /** Pre-rendered human-readable summary so simple apps can just print it. */
  std::string description;
};

}  // namespace ecnet
