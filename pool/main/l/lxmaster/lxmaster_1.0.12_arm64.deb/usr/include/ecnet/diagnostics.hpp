#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace ecmaster {
class EcMaster;
}

/**
 * SAFE_OP bring-up diagnostics, split from the logging layer: each `probe*` reads the bus into a
 * plain report struct, and `format()` renders it. This decouples "should I probe" (a bring-up
 * decision in `EcNetwork`) from "how/whether to print" (a logging decision). The probe bodies
 * are compiled only under `LXMASTER_DEBUG`; all call sites are inside `if constexpr
 * (ecdev::kDebugEnabled)` so release builds neither call nor link them.
 */
namespace ecnet::diag {

/** Optional SDO scalar: `present` is false when the read failed / object is absent. */
struct SdoU8  { bool present{false}; std::uint8_t  value{0}; };
struct SdoI8  { bool present{false}; std::int8_t   value{0}; };
struct SdoU16 { bool present{false}; std::uint16_t value{0}; };
struct SdoU32 { bool present{false}; std::uint32_t value{0}; };

/* --- SAFE_OP DC / sync probe (0x1C32/0x1C33 + interpolation objects) ----------------------- */

struct SafeOpDcSlave {
  int idx{0};
  std::uint16_t state{0};
  std::uint16_t al_status_code{0};
  bool has_dc{false};
  bool in_safe_op{false};
  bool al_error{false};
  bool dc_requested_but_absent{false};
  SdoU16 sm2_subcount, sm2_sync_mode;
  SdoU32 sm2_cycle_time, sm2_shift_time;
  SdoU16 sm3_subcount, sm3_sync_mode;
  SdoU32 sm3_cycle_time, sm3_shift_time;
  SdoU16 interp_time_period, interp_time_index;
};

struct SafeOpDcReport {
  bool dc_enabled{false};
  bool sync0_enabled{false};
  bool dc_or_sync0_disabled_note{false};
  bool ok{true};
  std::vector<SafeOpDcSlave> slaves;
};

/* --- Strict sync probe (0x1C12/0x1C13 PDO assignment) -------------------------------------- */

struct PdoAssignEntry {
  std::uint8_t sub{0};
  std::uint16_t pdo_index{0};
  bool readable{false};
};

struct PdoAssignObject {
  std::uint16_t index{0};
  bool subcount_readable{false};
  unsigned subcount{0};
  bool empty{false};
  std::vector<PdoAssignEntry> entries;
  unsigned not_printed{0};
};

struct StrictSyncSlave {
  int idx{0};
  PdoAssignObject rx;  ///< 0x1C12 (SM2)
  PdoAssignObject tx;  ///< 0x1C13 (SM3)
  bool has_dc{false};
  bool dc_path_enabled_but_absent{false};
};

struct StrictSyncReport {
  bool ok{true};
  std::vector<StrictSyncSlave> slaves;
};

/* --- Drive CoE error objects (0x1001, 0x6061, 0x603F, 0x1003) ------------------------------ */

struct CoEErrorSlave {
  int idx{0};
  std::uint16_t state{0};
  std::uint16_t al_status_code{0};
  SdoU8 error_register;        ///< 0x1001:0
  SdoI8 mode_of_op_display;    ///< 0x6061:0
  SdoU16 cia402_error_code;    ///< 0x603F:0
  SdoU8 predef_error_count;    ///< 0x1003:0
  std::vector<SdoU32> predef_error_history;  ///< 0x1003:k
  unsigned history_not_shown{0};
};

struct CoEErrorReport {
  std::string when_label;
  std::vector<CoEErrorSlave> slaves;
};

/* --- Probes (defined only under LXMASTER_DEBUG) ---------------------------------------------- */

SafeOpDcReport probeSafeOpDc(ecmaster::EcMaster& master, bool dc_enabled, bool sync0_enabled);
StrictSyncReport probeStrictSync(ecmaster::EcMaster& master);
CoEErrorReport probeDriveCoEErrors(ecmaster::EcMaster& master, const char* when_label);

/* --- Formatting (ADL-visible to ecdev::Logger::emit) --------------------------------------- */

std::string format(const SafeOpDcReport& r);
std::string format(const StrictSyncReport& r);
std::string format(const CoEErrorReport& r);

}  // namespace ecnet::diag
