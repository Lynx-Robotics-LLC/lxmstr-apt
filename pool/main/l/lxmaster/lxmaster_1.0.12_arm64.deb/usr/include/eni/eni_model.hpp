#pragma once

#include <cstdint>
#include <string>
#include <vector>

/**
 * Intermediate, master-agnostic model of an EtherCAT network configuration.
 *
 * It is the shared currency between two directions:
 *   - eni_gen (tool): merges a live SOEM scan with matched ESI metadata and
 *     serializes this model into an ETG.2100 EtherCATConfig (ENI).
 *   - eni_reader (runtime): parses a user-provided ENI back into this model so
 *     the runtime can build generic CiA402 devices without any vendor C++.
 *
 * Keeping the model independent of both SOEM and any XML library keeps the
 * merge/parse logic testable and the serializers free of discovery concerns.
 */
namespace eni {

/** One mapped object inside a PDO (e.g. 0x6040:0, Controlword, 16 bits, UINT). */
struct PdoEntry {
  std::uint16_t index{0};    ///< Object index; 0 denotes a padding/gap entry.
  std::uint8_t sub_index{0};
  std::uint8_t bit_len{0};
  std::string name;
  std::string data_type;     ///< ESI type token (UINT, DINT, ...); may be empty.
};

/** A process-data object (RxPdo/TxPdo) and its entry list. */
struct Pdo {
  std::uint16_t index{0};        ///< 0x1600.. (Rx) / 0x1A00.. (Tx).
  std::uint8_t sm{0};            ///< Sync manager this PDO is assigned to.
  bool is_tx{false};             ///< true = TxPdo (slave->master input).
  std::string name;
  bool fixed{false};
  bool mandatory{false};
  std::vector<PdoEntry> entries;
};

/** Sync manager configuration. SOEM SMtype: 0 unused,1 MbxWr,2 MbxRd,3 Out,4 In. */
struct SyncManager {
  std::uint8_t index{0};
  std::uint16_t start_address{0};
  std::uint8_t control_byte{0};
  std::uint16_t default_size{0};
  std::uint8_t type{0};
  bool enable{true};
};

/** Fieldbus Memory Management Unit record (logical <-> physical mapping). */
struct Fmmu {
  std::uint32_t log_start{0};
  std::uint16_t log_length{0};
  std::uint8_t log_start_bit{0};
  std::uint8_t log_end_bit{0};
  std::uint16_t phys_start{0};
  std::uint8_t phys_start_bit{0};
  std::uint8_t type{0};   ///< 1 = outputs, 2 = inputs.
  bool active{false};
};

/** Mailbox window + supported protocols. */
struct Mailbox {
  std::uint16_t out_start{0};   ///< Master->slave SM start (SOEM mbx_wo).
  std::uint16_t out_size{0};    ///< SOEM mbx_l.
  std::uint16_t in_start{0};    ///< Slave->master SM start (SOEM mbx_ro).
  std::uint16_t in_size{0};     ///< SOEM mbx_rl.
  bool coe{false};
  bool eoe{false};
  bool foe{false};
  bool soe{false};
  bool aoe{false};
  bool voe{false};
  bool present() const { return out_size != 0 || in_size != 0; }
};

/** Distributed-clock configuration, primarily from the ESI OpMode. */
struct DcConfig {
  bool has_dc{false};
  bool active{false};
  std::string op_mode_name;
  std::uint16_t assign_activate{0};  ///< ESI <AssignActivate> (e.g. 0x300).
  std::uint32_t cycle_time0_ns{0};
  std::uint32_t cycle_time1_ns{0};
  std::int32_t shift_time0_ns{0};
};

/** A single ESM-transition init command (register write or CoE mailbox write). */
struct InitCmd {
  std::string transition;            ///< "IP","PS","SP","SO","PI","SI",...
  std::string comment;
  bool is_coe{false};                ///< true = CoE SDO write, false = register write.
  // Register form:
  std::uint16_t ado{0};              ///< Address offset (ESC register).
  // CoE form:
  std::uint16_t index{0};
  std::uint8_t sub_index{0};
  bool complete_access{false};
  // Common:
  std::vector<std::uint8_t> data;    ///< Payload bytes (little-endian as on the wire).
};

/** Everything needed to emit (or consume) one <Slave> element. */
struct SlaveConfig {
  int position{0};                   ///< 1-based bus position (SOEM index).
  std::string name;
  std::uint16_t phys_addr{0};        ///< Configured station address (SOEM configadr).
  std::int16_t auto_inc_addr{0};     ///< 0, -1, -2, ... = 0 - (position-1).
  std::uint16_t alias{0};
  std::uint32_t vendor_id{0};
  std::uint32_t product_code{0};
  std::uint32_t revision{0};
  std::uint32_t serial{0};
  /** CANopen profile number (ESI <Profile><ProfileNo>): 402 drive, 401 I/O, 406 encoder, 5001
   *  modular, etc. 0 = absent. Used as the family-fallback classification tier when no device-class
   *  identity matches. */
  std::uint32_t profile_no{0};
  std::string physics;               ///< e.g. "YY", "Y" (from ESI Device Physics).

  std::vector<SyncManager> sync_managers;
  std::vector<Fmmu> fmmus;
  std::vector<Pdo> rx_pdos;          ///< Outputs (master->slave).
  std::vector<Pdo> tx_pdos;          ///< Inputs (slave->master).

  // Computed process-image placement (from SOEM IOmap pointers).
  std::uint32_t output_bits{0};
  std::uint32_t output_bit_offset{0};  ///< Bit offset of this slave's outputs in the image.
  std::uint32_t input_bits{0};
  std::uint32_t input_bit_offset{0};

  Mailbox mailbox;
  DcConfig dc;

  // Topology.
  std::uint16_t parent{0};           ///< 0 = master.
  std::uint8_t parent_port{0};
  std::uint8_t entry_port{0};

  std::vector<InitCmd> init_cmds;

  /** ETG.5001 modular slave: configured module ident list (CoE 0xF030), in slot order. Empty for
   *  monolithic slaves. eni_gen uses it to expand ESI modules into this slave's PDO set. */
  std::vector<std::uint32_t> module_idents;

  bool esi_matched{false};
  std::string esi_file;              ///< Source ESI path (diagnostics).
};

/** Aggregate logical process image (logical frame coverage). */
struct ProcessImage {
  std::uint32_t logical_base{0};     ///< Group logical start address.
  std::uint32_t outputs_byte_size{0};
  std::uint32_t inputs_byte_size{0};
  std::uint16_t expected_wkc{0};     ///< Expected working counter for the group (backend-specific).
};

/** One cyclic command (typically a single LRW over the whole image). */
struct CyclicCmd {
  std::string cmd{"LRW"};            ///< "LRW","LRD","LWR".
  std::uint32_t log_addr{0};
  std::uint16_t data_length{0};
  std::uint16_t cnt{0};              ///< Expected working counter.
  std::uint32_t input_offset{0};     ///< Byte offset into the input image.
  std::uint32_t output_offset{0};    ///< Byte offset into the output image.
  std::string comment;
};

struct CyclicFrame {
  std::vector<CyclicCmd> cmds;
};

/** Top-level configuration model. */
struct EniModel {
  std::string master_name{"LXMASTER"};
  std::vector<SlaveConfig> slaves;
  ProcessImage process_image;
  std::vector<CyclicFrame> cyclic_frames;
  std::uint32_t cycle_time_ns{0};
  bool dc_enabled{false};
};

/** ETG AssignActivate (ESC 0x0980) bit 8: SYNC0 enabled for this slave. */
inline constexpr std::uint16_t kDcAssignActivateSync0 = 0x0100;

/** True when the ENI marks this slave as a SYNC0 DC participant (has <DC> and AssignActivate). */
inline bool slaveNeedsSync0(const SlaveConfig& s) {
  return s.dc.has_dc && (s.dc.assign_activate & kDcAssignActivateSync0) != 0;
}

}  // namespace eni
