#pragma once

#include "devices/debug.hpp"  // kDebugEnabled, ProcessDataSnapshot

#include <cstdint>
#include <fstream>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace ecdev {

/* ============================================================================================
 * Small RT-aware logging framework.
 *
 * Three concerns are deliberately separated:
 *   1. Producers build a message string or a *report struct* (plain data).
 *   2. `format()` overloads turn a report into a line of text (presentation).
 *   3. An `ILogSink` transports the text (cout/cerr, file, in-memory capture).
 *
 * The `Logger` filters by severity (`LogLevel`) and subsystem (`LogCat` bitmask) and forwards
 * to its injected sink. There is no global mutable logger on the hot path: the owner (e.g.
 * `EcNetwork`) holds a `Logger` and hands a `Logger*` to the pieces that need it, mirroring the
 * way the old tracer pointer was injected.
 *
 * Hot-path rule: the RT cyclic thread must never call a `Logger`/sink directly. It enqueues a
 * `ProcessDataSnapshot` POD into a lock-free ring; the background worker drains it and logs.
 * ============================================================================================ */

/** Severity, most to least important. `Error`/`Warn` are always compiled in; `Info`/`Debug`/
 *  `Trace` are stripped from the binary when `LXMASTER_ENABLE_DEBUG=OFF`. */
enum class LogLevel : int { Error = 0, Warn = 1, Info = 2, Debug = 3, Trace = 4 };

/** Subsystem categories (bitmask). A `Logger`'s `category_mask` selects which ones are emitted. */
enum class LogCat : std::uint32_t {
  Bringup = 1u << 0,  ///< prepare()/start() phase walk, INIT/PRE_OP, shutdown milestones
  State   = 1u << 1,  ///< ESM transitions, AL status
  Pdo     = 1u << 2,  ///< mapping layout, per-cycle PDO hex dumps
  Cyclic  = 1u << 3,  ///< OP entry, WKC, watchdog, jitter
  DcSync  = 1u << 4,  ///< DC phase lock, sync stats
  Coe     = 1u << 5,  ///< SDO probes, CoE error objects
  Rt      = 1u << 6,  ///< RT scheduling identity
};

/** All categories enabled. */
inline constexpr std::uint32_t kLogCatAll = ~0u;

/** Lower-case stable name for a category token (CLI parsing / formatting). Empty for unknown. */
const char* logCatName(LogCat cat) noexcept;
/** Short upper-case tag for a level (e.g. "ERROR"). */
const char* logLevelName(LogLevel lvl) noexcept;
/** Parse a category token ("bringup", "dcsync", ...). Returns false (mask untouched) if unknown. */
bool parseLogCat(std::string_view token, std::uint32_t& mask_out) noexcept;
/** Parse a level token ("error".."trace"). Returns false if unknown. */
bool parseLogLevel(std::string_view token, LogLevel& level_out) noexcept;

/* --- Report structs (data) -----------------------------------------------------------------
 * These replace the old wide tracer methods. Producers fill one in; `format()` renders it. */

/** Post-mapping PDO dimensions for one slave. */
struct PdoLayoutReport {
  int slave_idx{0};
  std::uint32_t output_bytes{0};
  std::uint32_t input_bytes{0};
  std::uint32_t output_bits{0};
  std::uint32_t input_bits{0};
  const void* outputs{nullptr};
  const void* inputs{nullptr};
};

/** Working-counter expectation for the mapped group. */
struct WkcReport {
  int expected_wkc{0};
};

/** End-of-run host scheduling jitter histogram summary. */
struct JitterReport {
  std::uint32_t cycle_ns{0};
  std::uint64_t samples{0};
  std::int64_t min_ns{0};
  std::int64_t max_ns{0};
  std::int64_t mean_ns{0};
  std::int64_t mean_abs_ns{0};
};

/** End-of-run DC-sync alignment histogram summary (host wake vs reference-slave DC clock). */
struct DcSyncReport {
  std::uint32_t cycle_ns{0};
  std::uint64_t samples{0};
  std::int64_t min_ns{0};
  std::int64_t max_ns{0};
  std::int64_t mean_ns{0};
  std::int64_t mean_abs_ns{0};
  std::int64_t final_integral{0};
};

/* `format()` overloads. Found by the `Logger::emit` template via ordinary lookup (these) or
 * ADL (reports declared in other namespaces, e.g. `ecnet::diag`). */
std::string format(const PdoLayoutReport& r);
std::string format(const WkcReport& r);
std::string format(const JitterReport& r);
std::string format(const DcSyncReport& r);
std::string format(const ProcessDataSnapshot& snap);

/* --- Sinks (transport) --------------------------------------------------------------------- */

/** Pure transport: turns a finished line into output. Implementations must be self-contained. */
class ILogSink {
public:
  virtual ~ILogSink() = default;
  virtual void write(LogLevel level, LogCat cat, std::string_view line) = 0;
};

/** No-op sink. Backs `nullLogger()`. */
class NullSink final : public ILogSink {
public:
  void write(LogLevel, LogCat, std::string_view) override {}
};

/** Console sink: `Error`/`Warn` -> `std::cerr`, everything else -> `std::cout`. */
class ConsoleSink final : public ILogSink {
public:
  void write(LogLevel level, LogCat cat, std::string_view line) override;
};

/** In-memory sink for tests: records every line (with its level/category). */
class CapturingSink final : public ILogSink {
public:
  struct Entry {
    LogLevel level;
    LogCat cat;
    std::string line;
  };
  void write(LogLevel level, LogCat cat, std::string_view line) override;
  const std::vector<Entry>& entries() const noexcept { return entries_; }
  void clear() { entries_.clear(); }

private:
  std::vector<Entry> entries_;
};

/**
 * File sink with size-based rotation so long runs stay bounded on disk. When the active file
 * exceeds `max_bytes`, it is rotated to `<path>.1` .. `<path>.<max_files>` (oldest dropped).
 * Off the RT path (driven by the background logging worker / non-RT bring-up code).
 */
class FileSink final : public ILogSink {
public:
  explicit FileSink(std::string path, std::size_t max_bytes = 8u * 1024u * 1024u,
                    int max_files = 4);
  void write(LogLevel level, LogCat cat, std::string_view line) override;
  bool ok() const noexcept { return out_.is_open(); }

private:
  void rotateIfNeeded(std::size_t incoming);

  std::string path_;
  std::size_t max_bytes_;
  int max_files_;
  std::ofstream out_;
  std::size_t written_{0};
};

/* --- Logger (filter + dispatch) ------------------------------------------------------------ */

class Logger {
public:
  Logger() = default;
  Logger(ILogSink* sink, LogLevel min_level, std::uint32_t category_mask)
      : sink_(sink), min_level_(min_level), mask_(category_mask) {}

  /** True when a message at (level, cat) would be written: sink present, level in range, cat set. */
  bool enabled(LogLevel level, LogCat cat) const noexcept {
    return sink_ != nullptr && static_cast<int>(level) <= static_cast<int>(min_level_) &&
           (mask_ & static_cast<std::uint32_t>(cat)) != 0u;
  }

  /** Emit a free-form line. `const`: a logger forwards but owns no mutable state. */
  void emit(LogLevel level, LogCat cat, std::string_view msg) const {
    if (enabled(level, cat)) sink_->write(level, cat, msg);
  }

  /** Emit a report struct: formats via `format(report)` (ordinary lookup or ADL), then writes.
   *  SFINAE-constrained to types with a `format()` so it never shadows the string_view overload. */
  template <class Report, class = decltype(format(std::declval<const Report&>()))>
  void emit(LogLevel level, LogCat cat, const Report& report) const {
    if (enabled(level, cat)) sink_->write(level, cat, format(report));
  }

  ILogSink* sink() const noexcept { return sink_; }

private:
  ILogSink* sink_{nullptr};
  LogLevel min_level_{LogLevel::Error};
  std::uint32_t mask_{0};
};

/** Process-wide no-op logger (sink = shared `NullSink`, nothing enabled). Safe default. */
Logger& nullLogger();

}  // namespace ecdev

/* --- Macros --------------------------------------------------------------------------------
 * Explicit logger argument (no globals), matching the old `LX_TRACE(tracer, call)` injection.
 * The outer guard means `expr` (which may build a report or string) is only evaluated when the
 * message would actually be emitted.
 *
 * Error/Warn are ALWAYS compiled in. Info/Debug/Trace are wrapped in `if constexpr
 * (kDebugEnabled)`, so they (and the `expr` that feeds them) vanish from a release binary. */
#define LX_LOGE(logger, cat, expr)                                                          \
  do {                                                                                      \
    if ((logger).enabled(::ecdev::LogLevel::Error, (cat)))                                  \
      (logger).emit(::ecdev::LogLevel::Error, (cat), expr);                                 \
  } while (0)

#define LX_LOGW(logger, cat, expr)                                                          \
  do {                                                                                      \
    if ((logger).enabled(::ecdev::LogLevel::Warn, (cat)))                                   \
      (logger).emit(::ecdev::LogLevel::Warn, (cat), expr);                                  \
  } while (0)

#define LX_LOGI(logger, cat, expr)                                                          \
  do {                                                                                      \
    if constexpr (::ecdev::kDebugEnabled) {                                                 \
      if ((logger).enabled(::ecdev::LogLevel::Info, (cat)))                                 \
        (logger).emit(::ecdev::LogLevel::Info, (cat), expr);                                \
    }                                                                                       \
  } while (0)

#define LX_LOGD(logger, cat, expr)                                                          \
  do {                                                                                      \
    if constexpr (::ecdev::kDebugEnabled) {                                                 \
      if ((logger).enabled(::ecdev::LogLevel::Debug, (cat)))                                \
        (logger).emit(::ecdev::LogLevel::Debug, (cat), expr);                               \
    }                                                                                       \
  } while (0)

#define LX_LOGT(logger, cat, expr)                                                          \
  do {                                                                                      \
    if constexpr (::ecdev::kDebugEnabled) {                                                 \
      if ((logger).enabled(::ecdev::LogLevel::Trace, (cat)))                                \
        (logger).emit(::ecdev::LogLevel::Trace, (cat), expr);                               \
    }                                                                                       \
  } while (0)
