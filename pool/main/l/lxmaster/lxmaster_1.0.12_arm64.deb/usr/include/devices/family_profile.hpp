#pragma once

#include "devices/profile_registry.hpp"

#include <memory>

namespace ecdev {

/**
 * Family-fallback factory. When no identity class matches a slave, this claims it (at
 * `claim_score::kProfileFamily`) by the slave's CANopen profile number
 * (`eni::SlaveConfig::profile_no`) and builds the matching behavioural profile:
 *   - 402 -> CiA402 drive   ({@link makeCiA402DriveProfile})
 *   - 401 -> CiA401 I/O     ({@link makeCiA401IoProfile})
 *   - 406 -> CiA406 encoder ({@link makeCiA406EncoderProfile})
 *
 * Every other value -- including 5001 (ETG.5001 modular), 404, 0 (absent) and 0xFFFF -- does NOT
 * claim, because the number does not by itself imply a behavioural class; such slaves require an
 * explicit identity class and otherwise hit the caller's unmatched-slave policy (a hard error for
 * PDO-mapping slaves). This factory is self-registered into the builtin registry.
 */
std::unique_ptr<IProfileFactory> makeProfileFamilyFactory();

}  // namespace ecdev
