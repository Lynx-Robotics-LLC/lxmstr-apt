#pragma once

#include "eni/eni_model.hpp"

#include <cstdint>
#include <vector>

namespace ecdev {

class ISlaveServices;

/**
 * Generic, ENI-driven CoE PDO assignment. Programs each data SyncManager's assignment object
 * (0x1C1x) and the contained mapping objects (0x16xx RxPDO / 0x1Axx TxPDO) to EXACTLY what the
 * ENI `<Slave>` describes -- for any CoE device, not just CiA402 drives. This replaces the
 * hardcoded 0x1600/0x1A00 remap that used to live in `CiA402Device`/`CiA402PdoCodec`.
 *
 * It is applied generically by {@link GenericEniDevice} in the PreOP PO2SO hook, before the
 * device profile's own configuration. The backend's config-map step then computes the SM lengths, FMMUs,
 * and the logical process image from the assignment we just programmed -- so the byte offsets in
 * the {@link ProcessImage} (also derived from the same ENI PDOs) line up with the live IOmap.
 *
 * Reaches the master only through {@link ISlaveServices} (no backend types here).
 */
class PdoAssignment {
public:
  /** Build the assignment plan from an ENI slave (its sync managers + rx/tx PDOs). */
  static PdoAssignment fromSlaveConfig(const eni::SlaveConfig& slave);

  /** True when there is at least one mapped data SM to program. */
  bool empty() const noexcept { return groups_.empty(); }

  /** Program the assignment over CoE. Returns the aggregate working counter. */
  int apply(ISlaveServices& svc) const;
  /** Read back assignment + mapping counts to confirm the plan is active. */
  bool verify(ISlaveServices& svc) const;
  /** Aggregate WKC expected from `apply()` when every SDO succeeds once. */
  int expectedWkc() const noexcept { return expected_wkc_; }

  struct PdoPlan {
    std::uint16_t index{0};                 ///< Mapping object index (0x16xx / 0x1Axx).
    std::vector<std::uint32_t> entries;     ///< Packed mapping words (index<<16|sub<<8|bitlen).
  };
  struct SmGroup {
    std::uint16_t assignment_index{0};      ///< 0x1C10 + sm_index.
    std::vector<PdoPlan> pdos;
  };

private:
  std::vector<SmGroup> groups_;
  int expected_wkc_{0};
};

}  // namespace ecdev
