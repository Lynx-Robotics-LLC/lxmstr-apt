#pragma once

#include "devices/device_lifecycle.hpp"

#include <cstdint>
#include <string>

namespace ecdev {

class ISlaveServices;
class ProcessImage;
class IMotionProfile;
class IIoProfile;
class IEncoderProfile;

/**
 * Device-class behaviour plugged onto a {@link GenericEniDevice}. A profile understands the PDO
 * semantics of one EtherCAT device class (CiA 402 drive, CiA 401 digital/analog I/O, CiA 406
 * encoder, ...) and nothing about the backend, the ENI XML, or the master. It interacts with the world
 * through exactly two narrow contracts:
 *
 *   - {@link ISlaveServices} for setup-time SDO / register / PDO-pulse work (NOT on the RT path).
 *   - {@link ProcessImage} for per-cycle reads/writes of mapped objects (RT path).
 *
 * Selection is done by a {@link ProfileRegistry}; a new device class is added by registering a
 * new profile, with no change to the generic device or the orchestration layer.
 *
 * Threading: `configurePreOp`/`prepareSafeOp`/shutdown hooks run on the bring-up/shutdown thread
 * while the bus is not in OPERATIONAL; `writeOutputs`/`readInputs` run on the RT cyclic thread.
 * A profile that exposes data to application threads must do so through its own lock-free state
 * (e.g. atomics), exactly as the facades expect.
 */
class IDeviceProfile : public IDeviceLifecycle {
public:
  ~IDeviceProfile() override = default;

  /** Stable identifier for diagnostics (e.g. "CiA402-drive"). */
  virtual const char* profileName() const = 0;

  /**
   * Resolve the static channel/PDO topology from the ENI-derived process image. Called once when
   * the profile is attached to its device (during binding, before `start()`), so facade capability
   * queries such as `IIoProfile::digitalOutputCount()` are valid as soon as the bus is bound —
   * before any live PRE_OP SDO work. The image carries only ENI geometry here (it is not yet bound
   * to the live IOmap), which is all a structural resolve needs. Default: no-op. Idempotent:
   * `configurePreOp` may resolve again from the same image during `start()`.
   */
  virtual void resolveTopology(const ProcessImage& image) { (void)image; }

  /* ---- Setup (bus not cycling). Return a non-empty string to abort bring-up with that reason. */
  virtual std::string configurePreOp(ISlaveServices& svc, ProcessImage& image) {
    (void)svc;
    (void)image;
    return {};
  }
  virtual std::string prepareSafeOp(ISlaveServices& svc, ProcessImage& image) {
    (void)svc;
    (void)image;
    return {};
  }

  /* ---- Cyclic (RT thread). `image` is bound to the live PDO bytes for this cycle. */
  virtual void writeOutputs(ProcessImage& image, std::uint64_t cycle_count) {
    (void)image;
    (void)cycle_count;
  }
  virtual void readInputs(const ProcessImage& image, bool wkc_valid, bool operational) {
    (void)image;
    (void)wkc_valid;
    (void)operational;
  }

  /* ---- Output priming before SAFE_OP (e.g. CiA402 controlword -> Shutdown). */
  virtual void primeOutputs(ProcessImage& image) { (void)image; }

  /* ---- Graceful shutdown coordination + fault/stop surfacing are inherited from
   * {@link IDeviceLifecycle}: prepareShutdown / readyForShutdown / requiresMotionShutdown /
   * hasLeftOperationEnabled / requiresAlShutdown / readyForAlShutdown / cyclicStopRequested /
   * cyclicStopReason / lastStatusWordForDiagnostics. Override the ones your device class needs. */

  /** End-of-run, after the RT thread has joined; safe to do SDO reads via `svc`. */
  virtual void captureExitDiagnostics(ISlaveServices& svc) { (void)svc; }

  /* ---- Capability queries: how the facade layer discovers what this profile exposes. A
   * profile returns a non-null pointer for each facade contract it implements. Default: none. */
  virtual IMotionProfile* asMotion() noexcept { return nullptr; }
  virtual IIoProfile* asIo() noexcept { return nullptr; }
  virtual IEncoderProfile* asEncoder() noexcept { return nullptr; }
};

}  // namespace ecdev
