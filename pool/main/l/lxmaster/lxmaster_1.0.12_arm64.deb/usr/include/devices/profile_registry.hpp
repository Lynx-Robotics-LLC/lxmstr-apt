#pragma once

#include "devices/motion_profile.hpp"

#include "eni/eni_model.hpp"

#include <cstdint>
#include <memory>
#include <vector>

namespace ecdev {

class IDeviceProfile;

/**
 * Claim-score tiers for {@link IProfileFactory::claim}. Classification is explicit, in priority
 * order: a device class that matches a precise `vendor_id`/`product_code` identity returns
 * `kIdentityPin` and always wins; failing that, the family fallback claims by the slave's CANopen
 * `profile_no` (402/401/406) at `kProfileFamily`. Anything that claims neither is left to the
 * caller (unmatched PDO-mapping slaves are a hard error). Tiers are spaced to leave headroom for
 * future bands.
 */
namespace claim_score {
constexpr int kNone = 0;
constexpr int kProfileFamily = 500;  ///< CANopen ProfileNo family fallback (no identity match).
constexpr int kIdentityPin = 1000;   ///< Identity-matched device class (highest priority).
}  // namespace claim_score

/** Inputs a factory uses to decide on and build a profile for one ENI slave. */
struct ProfileSelectionInput {
  const eni::SlaveConfig* slave{nullptr};
  /** Initial operating mode baked into the profile at construction (CSP default). Overridable at
   *  runtime via Axis::configure() between prepare() and start(). */
  DriveOpMode op_mode{DriveOpMode::Csp};
  /** Initial auto fault-reset/recover flag (off by default). Overridable via Axis::configure(). */
  bool auto_fault_reset_and_recover{false};
  /** Clear a residual fault present at OP entry (before the drive has ever enabled this run) with a
   *  bounded reset window instead of latching a stop. On by default; mid-run faults stay terminal. */
  bool startup_fault_autoreset{true};
};

/**
 * Builds the device-class profile for one slave. A new device class is supported by adding a new
 * factory (typically via {@link makeIdentityProfileFactory} + `LXMASTER_REGISTER_DEVICE`); the
 * generic device and orchestration layer never change.
 */
class IProfileFactory {
public:
  virtual ~IProfileFactory() = default;
  virtual const char* name() const = 0;
  /**
   * Claim strength for `slave`: `claim_score::kNone` = does not handle this slave; a positive value
   * = this factory serves the slave (see {@link claim_score}). The registry picks the
   * highest-claiming factory (deterministic by registration order on ties).
   */
  virtual int claim(const eni::SlaveConfig& slave) const = 0;
  virtual std::unique_ptr<IDeviceProfile> create(const ProfileSelectionInput& in) const = 0;
};

/**
 * Registry of {@link IProfileFactory} plugins. `select()` returns the best-claiming profile for a
 * slave, or null when no factory claims it (the caller decides what an unmatched slave means).
 *
 * The process-wide {@link builtin} registry is populated entirely by self-registering device-class
 * translation units (`LXMASTER_REGISTER_DEVICE`); there is no central list of built-in factories.
 */
class ProfileRegistry {
public:
  void registerFactory(std::unique_ptr<IProfileFactory> factory);
  std::unique_ptr<IDeviceProfile> select(const ProfileSelectionInput& in) const;
  /**
   * Like `select(in)`, but also considers app-supplied factories (e.g.
   * `NetworkConfig::extra_profile_factories`) ahead of the built-ins, so an application can bind a
   * device class for one run without static registration. Ties favour `extra_factories`.
   */
  std::unique_ptr<IDeviceProfile> select(
      const ProfileSelectionInput& in,
      const std::vector<std::shared_ptr<IProfileFactory>>& extra_factories) const;

  /** The process-wide registry, populated by self-registering device-class TUs at static init. */
  static ProfileRegistry& builtin();

private:
  std::vector<std::unique_ptr<IProfileFactory>> factories_;
};

}  // namespace ecdev
