#pragma once

#include <cstdint>
#include <string>

namespace ecdev {

/**
 * Shutdown-coordination + stop/diagnostics predicate contract shared by the orchestration-facing
 * {@link IEthercatDevice} and the device-class {@link IDeviceProfile}. This is the single source of
 * truth for the graceful-shutdown phase gates; both interfaces used to declare the same nine methods
 * independently and {@link GenericEniDevice} hand-forwarded each to its profile. Now the profile
 * implements this mixin directly and the generic device exposes its profile through one
 * `lifecycle()` hook, so the contract and its defaults live in exactly one place.
 *
 * Graceful shutdown runs as up to three ordered phases (driven by `EcNetwork`, logged S1/S2/S3):
 *   Phase 1 (motion):  while PDO still flows, wait until each drive has left Operation Enabled.
 *                      Gated by `requiresMotionShutdown()` / `hasLeftOperationEnabled()`.
 *   Phase 2 (resting): wait until every device is safe to stop cycling (the RT thread then stops).
 *                      Gated by `readyForShutdown()`.
 *   Phase 3 (AL gate): before walking the bus state down, wait until each device is safe for that
 *                      wind-down. Gated by `requiresAlShutdown()` / `readyForAlShutdown()`.
 * Devices that do not opt into a phase (the defaults below) trivially satisfy it.
 */
class IDeviceLifecycle {
public:
  virtual ~IDeviceLifecycle() = default;

  /**
   * Signal that the device should start releasing its actuator *while PDO is still flowing* (RT
   * thread still running). CiA402 drives override this to walk the DS402 FSM toward Switch On
   * Disabled so the motor brake/torque is released gracefully before the bus state is walked down.
   */
  virtual void prepareShutdown() {}

  /** Phase 2 gate: device is safe to stop cycling. Default: always ready. */
  virtual bool readyForShutdown() const noexcept { return true; }

  /** Phase 1 applies to this device (it must leave Operation Enabled before cycling stops). */
  virtual bool requiresMotionShutdown() const noexcept { return false; }

  /** Phase 1 complete: the device has left Operation Enabled (or faulted). */
  virtual bool hasLeftOperationEnabled() const noexcept { return true; }

  /** Phase 3 applies to this device (it must reach a safe state before AL wind-down). */
  virtual bool requiresAlShutdown() const noexcept { return false; }

  /** Phase 3 complete: the device is safe for AL wind-down. Default: always ready. */
  virtual bool readyForAlShutdown() const noexcept { return true; }

  /** When true, the RT cyclic thread should exit and surface `cyclicStopReason()`. */
  virtual bool cyclicStopRequested() const noexcept { return false; }

  /** Human-readable reason for `cyclicStopRequested()` (empty if not requested). */
  virtual std::string cyclicStopReason() const { return {}; }

  /** Optional statusword for shutdown debug logs. */
  virtual std::uint16_t lastStatusWordForDiagnostics() const noexcept { return 0; }
};

/**
 * Shared default-valued lifecycle used when a device carries no profile (a passive slave). The
 * non-virtual delegators on {@link IEthercatDevice} route here so a profile-less device reports the
 * same neutral defaults the hand-written null-guards used to return.
 */
inline const IDeviceLifecycle& noDeviceLifecycle() noexcept {
  static const IDeviceLifecycle instance;
  return instance;
}

}  // namespace ecdev
