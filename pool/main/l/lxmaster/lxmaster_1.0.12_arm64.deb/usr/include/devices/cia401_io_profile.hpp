#pragma once

#include "devices/generic_io_profile.hpp"

#include <memory>

namespace ecdev {

struct ProfileSelectionInput;

/** Build a CiA401IoProfile. Bind it to a device identity with `makeIdentityProfileFactory`. */
std::unique_ptr<IDeviceProfile> makeCiA401IoProfile(const ProfileSelectionInput& in);

/**
 * CiA 401 (CANopen generic I/O) profile. A dedicated profile for genuine CoE CiA401 devices,
 * selected ahead of {@link GenericIoProfile} for slaves that expose the CiA401 standard object
 * ranges over a CoE mailbox. The channel model is inherited from `GenericIoProfile`; this class
 * is the seam where CiA401-specific setup (configuration objects, input filters, interrupt masks)
 * would be added. Non-CoE / vendor I/O terminals fall through to `GenericIoProfile` instead.
 */
class CiA401IoProfile final : public GenericIoProfile {
public:
  const char* profileName() const override { return "CiA401-io"; }
};

}  // namespace ecdev
