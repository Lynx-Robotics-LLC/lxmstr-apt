#pragma once

#include "devices/profile_registry.hpp"

/**
 * Register a device class into the process-wide {@link ecdev::ProfileRegistry::builtin} registry at
 * static-initialization time. `tag` is a unique identifier within the translation unit (used to
 * name the internal-linkage registrar); `factory_expr` is an expression yielding a
 * `std::unique_ptr<ecdev::IProfileFactory>` (typically `ecdev::makeIdentityProfileFactory(...)`).
 *
 * Usage (one per device file):
 *   LXMASTER_REGISTER_DEVICE(a6,
 *       ecdev::makeIdentityProfileFactory({0x00400000, 0x0715},
 *                                         ecdev::makeCiA402DriveProfile, "cia402:stepperonline-a6"));
 *
 * IMPORTANT (linker): a self-registering TU is referenced by nothing, so a static library will
 * drop it (and its registrar) unless the consuming target links the device library whole-archive
 * (`-Wl,--whole-archive` / CMake `$<LINK_LIBRARY:WHOLE_ARCHIVE,...>`). The in-tree apps and the
 * merged liblxmaster.so do this; an external device-support library must do the same.
 */
#define LXMASTER_REGISTER_DEVICE(tag, factory_expr)                          \
  namespace {                                                              \
  const bool lxmaster_dev_registered_##tag = [] {                           \
    ::ecdev::ProfileRegistry::builtin().registerFactory((factory_expr));   \
    return true;                                                           \
  }();                                                                     \
  }  // namespace
