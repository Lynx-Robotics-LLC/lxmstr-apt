#pragma once

#include "devices/device.hpp"

#include "ecmaster/slave_handler.hpp"

#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace ecmaster {
class EcMaster;
}

namespace ecdev {

struct PendingDevice {
  std::uint32_t vendor_id{0};
  std::uint32_t product_id{0};
  std::uint32_t revision{0};   ///< ENI-configured revision (for the compatibility check).
  int position{0};             ///< 1-based bus position this device must bind to (from the ENI).
  std::string name;            ///< ENI slave name (for diagnostics).
  std::unique_ptr<IEthercatDevice> device;
  bool bound{false};
};

struct DeviceBindOptions {
  Logger* logger{nullptr};
};

struct DeviceBindResult {
  std::vector<std::unique_ptr<ecmaster::ISlaveHandler>> handlers;
  std::vector<IEthercatDevice*> devices;
  std::vector<std::string> unmatched_warnings;
};

/**
 * Match pre-constructed `pending` devices to discovered slaves, install PO2SO hooks, and
 * return index-aligned handler/device vectors (index 0 unused, SOEM 1-based).
 */
DeviceBindResult bindPendingDevices(ecmaster::EcMaster& master,
                                    std::vector<PendingDevice>& pending,
                                    const DeviceBindOptions& opts);

}  // namespace ecdev
