#pragma once
// Single public entry point for LXMASTER consumers.
//
// ec_network.hpp already pulls in network_config.hpp (NetworkConfig, SyncMode,
// SyncTraceSample, SyncTracePhase) plus the facade handles (Axis, IoModule,
// Encoder) and DriveOpMode; bus_fault.hpp adds the fault reporting types.
// Include this one header and use the flat `lxmaster::` namespace.
#include "ecnet/bus_fault.hpp"
#include "ecnet/ec_network.hpp"

namespace lxmaster {

// Network facade + configuration.
using ecnet::EcNetwork;
using ecnet::NetworkConfig;
using ecnet::SyncMode;

// Diagnostics surfaced by EcNetwork.
using ecnet::BusFault;
using ecnet::LostSlave;
using ecnet::SyncTracePhase;
using ecnet::SyncTraceSample;

// Thin device handles returned by EcNetwork.
using ecfacade::Axis;
using ecfacade::Encoder;
using ecfacade::GenericDevice;
using ecfacade::IoModule;

// Drive operating modes.
using ecdev::DriveOpMode;

}  // namespace lxmaster
