#!/usr/bin/env python3
"""Analyze servo_sin_demo --sync-trace-file output (concepts 1, 2, 4 of dc-sync debug playbook).

Parses the mixed header + TSV rows written by printSyncTraceReport(). For each data row with
tab-separated fields seq, rt_cycle, op_cycle, dc_delta_ns, jitter_err_ns, abs_dc, sync_violation:
  - Concept 2: ring_capacity vs total_writes from header lines
  - Concept 1: correlate |jitter_err_ns| vs abs_dc on sync_violation YES rows
  - Concept 4: bucket YES rows by op_cycle (warmup vs steady)

Usage:
  ./scripts/rt/diag/analyze-sync-trace.py trace.tsv
  ./scripts/rt/diag/analyze-sync-trace.py trace.tsv --warmup-op-cycles 500
  ./scripts/rt/diag/analyze-sync-trace.py trace.tsv --machine   # FINDING key=value lines only

  (normally invoked automatically by 'lxmstr diag dc-sync')
"""
from __future__ import annotations

import argparse
import math
import re
import sys
from typing import List, Tuple


def pearson(xs: List[float], ys: List[float]) -> float | None:
    n = len(xs)
    if n < 2:
        return None
    mx = sum(xs) / n
    my = sum(ys) / n
    num = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    dx = math.sqrt(sum((x - mx) ** 2 for x in xs))
    dy = math.sqrt(sum((y - my) ** 2 for y in ys))
    if dx == 0 or dy == 0:
        return None
    return num / (dx * dy)


def parse_report(text: str) -> Tuple[dict, List[Tuple[int, int, int, int, int, int, str]]]:
    meta: dict = {}
    rows: List[Tuple[int, int, int, int, int, int, str]] = []

    ring_m = re.search(r"ring_capacity=(\d+)\s+total_writes=(\d+)", text)
    if ring_m:
        meta["ring_capacity"] = int(ring_m.group(1))
        meta["total_writes"] = int(ring_m.group(2))
        rc, tw = meta["ring_capacity"], meta["total_writes"]
        meta["ring_overwrite"] = bool(rc > 0 and tw > rc)

    vw_m = re.search(r"violation_window_ns=(\d+)\s+violation_cycles=(\d+)", text)
    if vw_m:
        meta["violation_window_ns"] = int(vw_m.group(1))
        meta["violation_cycles"] = int(vw_m.group(2))

    for line in text.splitlines():
        parts = line.split("\t")
        if len(parts) != 7:
            continue
        if not parts[0].strip().isdigit():
            continue
        try:
            seq = int(parts[0])
            rt_c = int(parts[1])
            op_c = int(parts[2])
            dc_d = int(parts[3])
            jit = int(parts[4])
            abs_dc = int(parts[5])
            viol = parts[6].strip()
        except ValueError:
            continue
        rows.append((seq, rt_c, op_c, dc_d, jit, abs_dc, viol))

    return meta, rows


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("tsv_file", help="Path to sync-trace output file")
    ap.add_argument(
        "--warmup-op-cycles",
        type=int,
        default=500,
        metavar="N",
        help="op_cycle <= N treated as startup bucket (default 500)",
    )
    ap.add_argument(
        "--machine",
        action="store_true",
        help="Print FINDING key=value lines only (for scripts)",
    )
    args = ap.parse_args()

    try:
        raw = open(args.tsv_file, encoding="utf-8", errors="replace").read()
    except OSError as e:
        print(f"analyze-sync-trace: {e}", file=sys.stderr)
        return 1

    meta, rows = parse_report(raw)

    def emit_machine() -> None:
        yes = [r for r in rows if r[6].upper() == "YES"]
        early = sum(1 for r in yes if r[2] <= args.warmup_op_cycles)
        late = len(yes) - early
        pearson_r = None
        if len(yes) >= 2:
            aj = [float(abs(r[4])) for r in yes]
            ad = [float(r[5]) for r in yes]
            pearson_r = pearson(aj, ad)

        def finding(k: str, v: object) -> None:
            print(f"FINDING {k}={v}")

        finding("ring_overwrite", 1 if meta.get("ring_overwrite") else 0)
        finding("ring_capacity", meta.get("ring_capacity", ""))
        finding("total_writes", meta.get("total_writes", ""))
        finding("violation_cycles", meta.get("violation_cycles", ""))
        finding("violation_window_ns", meta.get("violation_window_ns", ""))
        finding("yes_rows_in_file", len(yes))
        finding("yes_warmup_bucket", early)
        finding("yes_steady_bucket", late)
        finding(
            "pearson_r_jitter_absdc",
            "" if pearson_r is None else f"{pearson_r:.6f}",
        )
        coupled = False
        if pearson_r is not None and abs(pearson_r) >= 0.35:
            coupled = True
        finding("hypothesis_coupled_host_jitter", 1 if coupled else 0)
        dc_tune_hint = len(yes) >= 2 and not coupled
        finding("hypothesis_dc_tune_priority", 1 if dc_tune_hint else 0)

    if args.machine:
        emit_machine()
        return 0

    print("=== Concept 2 — measurement / ring ===")
    if "ring_capacity" in meta:
        print(
            f"  ring_capacity={meta['ring_capacity']}  total_writes={meta['total_writes']}  "
            f"overwrite_warn={'YES' if meta.get('ring_overwrite') else 'no'}"
        )
        if meta.get("ring_overwrite"):
            print(
                "  ACTION: raise --sync-trace N so N >= OP cycles in the analyzed window "
                "(see playbook)."
            )
    else:
        print("  (no ring_capacity/total_writes lines found — is this a sync-trace file?)")

    if "violation_cycles" in meta:
        print(
            f"  violation_window_ns={meta.get('violation_window_ns')}  "
            f"violation_cycles={meta['violation_cycles']} (full run counter)"
        )

    yes = [r for r in rows if r[6].upper() == "YES"]
    print(f"\n=== Concept 4 — startup vs steady (warmup op_cycle <= {args.warmup_op_cycles}) ===")
    early = [r for r in yes if r[2] <= args.warmup_op_cycles]
    late = [r for r in yes if r[2] > args.warmup_op_cycles]
    print(f"  YES rows in file: {len(yes)} (may be < violation_cycles if ring wrapped)")
    print(f"  YES with op_cycle <= warmup: {len(early)}")
    print(f"  YES with op_cycle >  warmup: {len(late)}")

    print("\n=== Concept 1 — |jitter_err| vs abs_dc on YES rows ===")
    if len(yes) < 2:
        print("  Not enough YES rows for correlation (need >= 2).")
        return 0

    aj = [float(abs(r[4])) for r in yes]
    ad = [float(r[5]) for r in yes]
    r_p = pearson(aj, ad)
    if r_p is None:
        print("  Pearson r: n/a")
    else:
        print(f"  Pearson r(|jitter_err|, abs_dc) over YES rows: {r_p:.4f}")

    hi_j = sum(1 for r in yes if abs(r[4]) > 5_000)
    hi_d = sum(1 for r in yes if r[5] > 10_000)
    both = sum(1 for r in yes if abs(r[4]) > 5_000 and r[5] > 10_000)
    print(f"  heuristic: |jitter|>5µs on YES rows: {hi_j}/{len(yes)}")
    print(f"  heuristic: abs_dc>10µs on YES rows: {hi_d}/{len(yes)}")
    print(f"  heuristic: both above thresholds: {both}/{len(yes)}")
    print(
        "  Interpret: high r + many |jitter| spikes → host grid / IRQ / scheduling (concepts 3,5,7). "
        "Low r + large abs_dc with small jitter → DC PI / clamp / window (concept 6)."
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
