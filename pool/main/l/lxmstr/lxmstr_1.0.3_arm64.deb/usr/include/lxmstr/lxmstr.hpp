#pragma once
// Single public entry point for LXMSTR consumers.
//
// ec_network.hpp already pulls in network_config.hpp (NetworkConfig, SyncMode,
// SyncTraceSample, SyncTracePhase) plus the facade handles (Axis, IoModule,
// Encoder) and DriveOpMode; bus_fault.hpp adds the fault reporting types.
// Include this one header and use the flat `lxmstr::` namespace.
#include "ecnet/bus_fault.hpp"
#include "ecnet/ec_network.hpp"

namespace lxmstr {

// Network facade + configuration.
using ecnet::EcNetwork;
using ecnet::NetworkConfig;
using ecnet::SyncMode;

// Diagnostics surfaced by EcNetwork.
using ecnet::BusFault;
using ecnet::LostSlave;
using ecnet::SyncTracePhase;
using ecnet::SyncTraceSample;

// Thin device handles returned by EcNetwork.
using ecfacade::Axis;
using ecfacade::Encoder;
using ecfacade::IoModule;

// Drive operating modes.
using ecdev::DriveOpMode;

}  // namespace lxmstr
