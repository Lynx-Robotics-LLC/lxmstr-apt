#pragma once

namespace ecmaster {

/**
 * Real-time scheduling request for the calling thread / process. Sits alongside
 * `RtCycleClock` because both are OS-level RT primitives independent of SOEM and of any
 * particular device: the cyclic master, and any example that runs a hand-rolled cyclic
 * loop, want the exact same `mlockall` + `SCHED_FIFO` + CPU-affinity setup.
 */
struct RtSchedulingParams {
  /** When false, `applyRealtimeScheduling` is a no-op and returns true. */
  bool enable{true};
  /** SCHED_FIFO priority (1..99). <= 0 leaves the scheduling policy untouched. */
  int rt_priority{49};
  /** Pin the calling thread to this CPU. < 0 leaves affinity untouched. */
  int cpu_affinity{-1};
};

/**
 * Apply `mlockall(MCL_CURRENT | MCL_FUTURE)`, `SCHED_FIFO` at `rt_priority`, and CPU affinity
 * to the calling thread. Failures are logged to stderr (with the canonical `[rt]` prefix) and
 * cause a `false` return, but are non-fatal — a missing capability degrades jitter, it does
 * not break correctness. Returns true when every requested step succeeded, or when
 * `params.enable` is false.
 *
 * Must be called on the thread that will run the cycle (the cyclic thread inherits scheduling
 * from its creator on Linux, so calling this on the main thread before spawning the RT thread
 * is sufficient and is what `EcNetwork::start()` does).
 */
bool applyRealtimeScheduling(const RtSchedulingParams& params);

}  // namespace ecmaster
