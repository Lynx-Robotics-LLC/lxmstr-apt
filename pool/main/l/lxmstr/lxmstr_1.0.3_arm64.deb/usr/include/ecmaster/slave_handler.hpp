#pragma once

#include <cstdint>

namespace ecmaster {

class EcMaster;

/**
 * Backend-neutral handle passed to per-slave configuration callbacks (PRE_OP config, SAFE_OP
 * prepare, shutdown capture). Carries only the master and the 1-based slave index; callbacks that
 * need the slave's discovered fields or process image obtain them via `master->slaveInfo(index)`
 * / `master->pdoImage(index)`.
 */
struct SlaveContext {
  EcMaster* master{nullptr};
  std::uint16_t slave_index{0};  // 1 .. slaveCount
};

/** User-defined behaviour for one EtherCAT slave. */
class ISlaveHandler {
public:
  virtual ~ISlaveHandler() = default;

  /** Invoked during `configMap()` (PRE_OP mailbox access) before sync managers are sized. */
  virtual int onPrepareToMap(SlaveContext& ctx) = 0;
};

}  // namespace ecmaster
