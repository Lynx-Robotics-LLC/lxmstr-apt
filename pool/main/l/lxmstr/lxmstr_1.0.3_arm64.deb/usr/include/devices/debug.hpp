#pragma once

#include <cstddef>
#include <cstdint>
#include <string_view>

namespace ecmaster {
class EcMaster;
struct SlaveInfo;
}

namespace ecdev {

/**
 * Fixed-size process-data snapshot used by the cyclic executor to hand off per-cycle diagnostic
 * state to a background printer thread. Populated by the RT thread from the per-slave PDO
 * pointers and consumed later (milliseconds-scale) by a worker that calls `processDataSnapshot`.
 * The arrays are capped at 64 bytes — every CiA402 drive we target maps 8-12 bytes in each
 * direction, and capping avoids unbounded stack/ring usage. Larger PDO regions are truncated
 * (the struct records the original length for the printer to note).
 */
struct ProcessDataSnapshot {
  static constexpr std::size_t kMaxBytes = 64;

  int            slave_idx{0};
  int            wkc{0};
  int            expected_wkc{0};
  std::uint32_t  cycle_ns_hint{0};
  std::uint16_t  slave_state{0};
  std::uint16_t  al_statuscode{0};
  std::uint8_t   islost{0};

  std::size_t    output_bytes_total{0};  /* original Obytes (may exceed kMaxBytes) */
  std::size_t    input_bytes_total{0};   /* original Ibytes (may exceed kMaxBytes) */
  std::size_t    output_bytes_copied{0}; /* min(Obytes, kMaxBytes) */
  std::size_t    input_bytes_copied{0};  /* min(Ibytes, kMaxBytes) */

  std::uint8_t   outputs[kMaxBytes]{};
  std::uint8_t   inputs[kMaxBytes]{};
};

/**
 * Compile-time gate: `true` when the top-level CMake option `LXMSTR_ENABLE_DEBUG=ON`,
 * otherwise `false`. Every `LX_TRACE(...)` call site is wrapped in `if constexpr
 * (kDebugEnabled)`, so with the flag off the entire debug call tree is dead-code
 * eliminated — symbols, strings, and vtables of `ConsoleDebugTracer` are all dropped
 * by the linker.
 */
#ifdef LXMSTR_DEBUG
constexpr bool kDebugEnabled = true;
#else
constexpr bool kDebugEnabled = false;
#endif

/**
 * Print-only diagnostics interface. Implementations are expected to never be called
 * in a release build (when `kDebugEnabled = false`), so any side effects here are safe
 * to rely on only during development / tuning.
 *
 * Functions that return `bool` return the success of a sanity check. `NullDebugTracer`
 * returns `true` so release-build code that accidentally reaches them (should never
 * happen with `LX_TRACE`) does not abort.
 */
class IDebugTracer {
public:
  virtual ~IDebugTracer() = default;

  /** Free-form log message. */
  virtual void message(std::string_view msg) = 0;

  /** Post-mapping PDO dimensions for one slave. */
  virtual void slavePdoInfo(int slave_idx, const ecmaster::SlaveInfo& s) = 0;

  /** Working-counter expectations for the mapped group. */
  virtual void groupWkcInfo(int expected_wkc) = 0;

  /**
   * Cycle data dump with WKC status + hex PDO dumps. Called by a background (non-RT) worker
   * thread that consumes `ProcessDataSnapshot`s captured by the cyclic executor; this keeps
   * `std::cout` out of the RT path where blocking stdio would add hundreds-of-microseconds
   * spikes to the cycle.
   */
  virtual void processDataSnapshot(const ProcessDataSnapshot& snap) = 0;

  /** Probe DC/SM SDOs in SAFE_OP. Returns true if checks pass. */
  virtual bool runSafeOpDcChecks(ecmaster::EcMaster& master, bool dc_enabled, bool sync0_enabled) = 0;

  /** 0x1C12/0x1C13 + SOEM DC mirror consistency check. Returns true on pass. */
  virtual bool runStrictSyncChecks(ecmaster::EcMaster& master, std::uint32_t cycle_ns, bool no_dc,
                                   bool no_sync0) = 0;

  /** CoE error objects (0x1001, 0x603F, 0x1003, 0x6061). */
  virtual void printDriveCoEErrors(ecmaster::EcMaster& master, const char* when_label) = 0;

  /** End-of-run jitter histogram. */
  virtual void jitterStats(std::uint32_t cycle_ns, std::uint64_t samples, std::int64_t min_ns,
                           std::int64_t max_ns, std::int64_t mean_ns, std::int64_t mean_abs_ns) = 0;

  /**
   * End-of-run DC-sync alignment histogram: host cyclic wake vs. reference-slave DC clock.
   * `delta_ns` is the signed phase error fed to the PI controller *before* it applies `toff`
   * — so it reflects how far out of phase the host would be without correction. A well-tuned
   * system keeps |delta| well below the slave's configured sync-error window.
   *
   * `final_integral` is the controller's integrator at shutdown. Large or growing values
   * mean the host/slave crystals disagree and the PI is continually compensating — useful
   * for spotting long-run drift that no longer fits in the sync window.
   */
  virtual void dcSyncStats(std::uint32_t cycle_ns, std::uint64_t samples, std::int64_t min_ns,
                           std::int64_t max_ns, std::int64_t mean_ns, std::int64_t mean_abs_ns,
                           std::int64_t final_integral) = 0;
};

/** No-op tracer — safe for any build; returns pass from check methods. */
class NullDebugTracer final : public IDebugTracer {
public:
  void message(std::string_view) override {}
  void slavePdoInfo(int, const ecmaster::SlaveInfo&) override {}
  void groupWkcInfo(int) override {}
  void processDataSnapshot(const ProcessDataSnapshot&) override {}
  bool runSafeOpDcChecks(ecmaster::EcMaster&, bool, bool) override { return true; }
  bool runStrictSyncChecks(ecmaster::EcMaster&, std::uint32_t, bool, bool) override { return true; }
  void printDriveCoEErrors(ecmaster::EcMaster&, const char*) override {}
  void jitterStats(std::uint32_t, std::uint64_t, std::int64_t, std::int64_t, std::int64_t,
                   std::int64_t) override {}
  void dcSyncStats(std::uint32_t, std::uint64_t, std::int64_t, std::int64_t, std::int64_t,
                   std::int64_t, std::int64_t) override {}
};

/**
 * `std::cout`-backed tracer with the same output format the pre-refactor `servo_demo` produced.
 * Compiled only when `LXMSTR_ENABLE_DEBUG=ON` (see debug.cpp); in release builds, instantiating
 * it is a link error, which is the whole point: we cannot accidentally include its code.
 */
class ConsoleDebugTracer final : public IDebugTracer {
public:
  void message(std::string_view msg) override;
  void slavePdoInfo(int slave_idx, const ecmaster::SlaveInfo& s) override;
  void groupWkcInfo(int expected_wkc) override;
  void processDataSnapshot(const ProcessDataSnapshot& snap) override;
  bool runSafeOpDcChecks(ecmaster::EcMaster& master, bool dc_enabled, bool sync0_enabled) override;
  bool runStrictSyncChecks(ecmaster::EcMaster& master, std::uint32_t cycle_ns, bool no_dc,
                           bool no_sync0) override;
  void printDriveCoEErrors(ecmaster::EcMaster& master, const char* when_label) override;
  void jitterStats(std::uint32_t cycle_ns, std::uint64_t samples, std::int64_t min_ns,
                   std::int64_t max_ns, std::int64_t mean_ns, std::int64_t mean_abs_ns) override;
  void dcSyncStats(std::uint32_t cycle_ns, std::uint64_t samples, std::int64_t min_ns,
                   std::int64_t max_ns, std::int64_t mean_ns, std::int64_t mean_abs_ns,
                   std::int64_t final_integral) override;
};

/** Process-wide `NullDebugTracer` singleton. Handy default for devices that need a reference. */
IDebugTracer& nullTracer();

}  // namespace ecdev

/**
 * Call a method on a tracer reference. With `LXMSTR_ENABLE_DEBUG=OFF` the entire statement
 * collapses to nothing at compile time (the `if constexpr` branch is discarded), so the
 * linker drops any ConsoleDebugTracer vtable, string literals, and SDO-probing code the
 * method would reference.
 *
 * Usage:
 *   LX_TRACE(*tracer, message("starting cyclic loop"));
 *   LX_TRACE(*tracer, processData(i, s, wkc, expected, cycle_ns));
 */
#define LX_TRACE(tracer, call)                                    \
  do {                                                            \
    if constexpr (::ecdev::kDebugEnabled) { (tracer).call; }      \
  } while (0)

/**
 * Guard a block that only makes sense in debug builds (e.g. sanity checks whose return value
 * is used for control flow). Expands to `if constexpr (true)` / `if constexpr (false)`.
 */
#define LX_IF_DEBUG if constexpr (::ecdev::kDebugEnabled)
