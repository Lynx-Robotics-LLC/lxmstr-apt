#pragma once

#include "devices/sync_mode.hpp"

#include <cstdint>

namespace ecdev {

/**
 * Setup-time services a device/profile may use against one slave while the bus is NOT cycling
 * in OPERATIONAL: CoE SDO transfers, ESC register transfers, a process-data exchange pulse, and
 * read-only access to the master's sync choice. This is the second narrow contract (besides
 * {@link ProcessImage}): it is the ONLY way a profile reaches the EtherCAT master, and it holds
 * no backend types in its interface, so profiles never include a backend header.
 *
 * Lifetime: an `ISlaveServices` is valid only during a configuration callback (PreOP config,
 * SAFE_OP prepare, shutdown capture). Never cache it for use on the RT cyclic path.
 */
class ISlaveServices {
public:
  virtual ~ISlaveServices() = default;

  /** 1-based bus index of the slave these services act on. */
  virtual std::uint16_t slaveIndex() const = 0;

  /** CoE SDO download. Returns the working counter (> 0 on success). */
  virtual int writeSdo(std::uint16_t index, std::uint8_t sub, bool complete_access,
                       const void* data, int size) = 0;
  /**
   * CoE SDO upload. `*size` is in/out: pass the buffer capacity, receive the bytes read.
   * Returns the working counter (> 0 on success).
   */
  virtual int readSdo(std::uint16_t index, std::uint8_t sub, bool complete_access, void* data,
                      int* size) = 0;

  /** Configured-address ESC register read (FPRD). Returns the working counter. */
  virtual int readRegister(std::uint16_t ado, void* data, std::uint16_t len) = 0;

  /** Exchange one PDO frame (send + receive). Used to warm up the mailbox / pulse outputs. */
  virtual void exchangeProcessData() = 0;

  /** Drain the backend's CoE/SoE error queue so a stale abort cannot masquerade as the next result. */
  virtual void drainErrors() = 0;
};

}  // namespace ecdev
