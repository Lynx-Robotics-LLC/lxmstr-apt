#pragma once

#include "devices/generic_io_profile.hpp"

#include <memory>

namespace ecdev {

class IProfileFactory;

/** Factory that claims true CoE CiA 401 digital/analog I/O slaves and builds a CiA401IoProfile. */
std::unique_ptr<IProfileFactory> makeCiA401IoFactory();

/**
 * CiA 401 (CANopen generic I/O) profile. A dedicated profile for genuine CoE CiA401 devices,
 * selected ahead of {@link GenericIoProfile} for slaves that expose the CiA401 standard object
 * ranges over a CoE mailbox. The channel model is inherited from `GenericIoProfile`; this class
 * is the seam where CiA401-specific setup (configuration objects, input filters, interrupt masks)
 * would be added. Non-CoE / vendor I/O terminals fall through to `GenericIoProfile` instead.
 */
class CiA401IoProfile final : public GenericIoProfile {
public:
  const char* profileName() const override { return "CiA401-io"; }
};

}  // namespace ecdev
