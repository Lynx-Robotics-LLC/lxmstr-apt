#pragma once

#include <cstdint>

namespace ecdev {

/**
 * Pure DS402 (CiA 402) drive state machine: given the drive's statusword and the
 * application's intent (target / disable / fault-reset), decide the controlword to command
 * this cycle. Contains NO SOEM / PDO / threading concerns — every input is a plain value and
 * every output is returned, so it is trivially unit-testable and reused unchanged by
 * `CiA402Device`'s RT `writeOutputs`.
 *
 * The object owns only the small amount of edge-tracking state the DS402 walk needs:
 *   - `reset_pulse_high_` — drives the rising/falling edge of the controlword bit-7 fault reset.
 *   - `reset_armed_`      — gates automatic fault reset until enough valid PDO cycles elapse.
 *   - `valid_pdo_streak_` — consecutive valid-WKC cycles feeding `reset_armed_`.
 *   - `first_cycle_done_` / `target_hold_` — seed the held CSP target to the drive's actual
 *     position on the first cycle, then track user / hold-actual updates.
 */
class CiA402Fsm {
public:
  /* DS402 statusword bit masks (0x6041) and state nibble values. */
  static constexpr std::uint16_t kStatusOperationEnabledBit = 0x0004;
  static constexpr std::uint16_t kStatusFaultBit = 0x0008;
  static constexpr std::uint16_t kStatusQuickStopInactiveBit = 0x0020;
  static constexpr std::uint16_t kStatusWarningBit = 0x0080;
  static constexpr std::uint16_t kStatusTargetReachedBit = 0x0400;
  static constexpr std::uint16_t kStatusInternalLimitBit = 0x0800;
  static constexpr std::uint16_t kStatusFollowingErrorBit = 0x2000;
  static constexpr std::uint16_t kStateMask = 0x006F;
  static constexpr std::uint16_t kStateSwitchOnDisabled = 0x0040;
  static constexpr std::uint16_t kStateReadyToSwitchOn = 0x0021;
  static constexpr std::uint16_t kStateSwitchedOn = 0x0023;
  static constexpr std::uint16_t kStateOperationEnabled = 0x0027;

  /* DS402 controlword (0x6040) commands. */
  static constexpr std::uint16_t kCwShutdown = 0x0006;
  static constexpr std::uint16_t kCwSwitchOn = 0x0007;
  static constexpr std::uint16_t kCwEnableOperation = 0x000F;
  static constexpr std::uint16_t kCwDisableVoltage = 0x0000;
  static constexpr std::uint16_t kCwFaultResetBit = 0x0080;

  /** Per-cycle inputs sampled from the PDO snapshot + application intent. */
  struct Inputs {
    std::uint16_t statusword{0};
    std::int32_t actual_position{0};
    bool have_user_target{false};
    std::int32_t user_target{0};
    bool user_disable{false};
    bool user_fault_reset{false};
    bool motion_fault_latched{false};
  };

  /** Behavioural switches mirrored from `CiA402Config`. */
  struct Config {
    bool auto_fault_reset_and_recover{false};
    bool shutdown_require_switch_on_disabled{true};
    bool hold_actual_position{true};
    /** CSV (cyclic velocity) / CST (cyclic torque): the int32 target is a velocity or torque, so
     * the neutral/held value (first cycle and "no user target") is 0 (stationary / no torque)
     * instead of the actual position. */
    bool zero_neutral_target{false};
  };

  struct Output {
    std::uint16_t controlword{kCwShutdown};
    std::int32_t target_position{0};
    /** True when a one-shot user fault-reset edge was consumed this cycle (caller clears it). */
    bool consumed_user_fault_reset{false};
  };

  /** Decide the controlword + held target for this cycle. Byte-identical to the legacy walk. */
  Output step(const Inputs& in, const Config& cfg) {
    if (!first_cycle_done_) {
      target_hold_ = cfg.zero_neutral_target ? 0 : in.actual_position;
      first_cycle_done_ = true;
    }

    Output out;
    std::uint16_t cw = kCwShutdown;
    const std::uint16_t sw_state = in.statusword & kStateMask;
    const bool fault_bit = (in.statusword & kStatusFaultBit) != 0;
    const bool block_recover = in.motion_fault_latched && !cfg.auto_fault_reset_and_recover;

    if (fault_bit) {
      /* CiA 402: rising edge on bit 7 clears fault. An explicit reset request
       * (`user_fault_reset`) always pulses bit 7; automatic (arming-gated) reset additionally
       * applies when `auto_fault_reset_and_recover` is enabled. Otherwise hold disable. */
      if (!cfg.auto_fault_reset_and_recover && !in.user_fault_reset) {
        cw = 0x0000;
      } else {
        const bool armed =
            in.user_fault_reset || (cfg.auto_fault_reset_and_recover && reset_armed_);
        if (!armed) {
          cw = 0x0000;
        } else if (reset_pulse_high_) {
          cw = 0x0000;
          reset_pulse_high_ = false;
          if (in.user_fault_reset) {
            out.consumed_user_fault_reset = true;
          }
        } else {
          cw = kCwFaultResetBit;
          reset_pulse_high_ = true;
        }
      }
    } else if (in.user_disable) {
      if (cfg.shutdown_require_switch_on_disabled) {
        if (sw_state == kStateSwitchOnDisabled) {
          cw = kCwDisableVoltage;
        } else if (sw_state == kStateReadyToSwitchOn) {
          /* CiA402: disable voltage from Ready to Switch On → Switch On Disabled. */
          cw = kCwDisableVoltage;
        } else {
          cw = kCwShutdown;
        }
      } else {
        cw = kCwShutdown;
      }
    } else if (sw_state == kStateSwitchOnDisabled) {
      cw = block_recover ? kCwDisableVoltage : kCwShutdown;
    } else if (sw_state == kStateReadyToSwitchOn) {
      cw = block_recover ? kCwDisableVoltage : kCwSwitchOn;
    } else if (sw_state == kStateSwitchedOn) {
      cw = block_recover ? kCwShutdown : kCwEnableOperation;
    } else if (sw_state == kStateOperationEnabled) {
      cw = kCwEnableOperation;
      if (in.have_user_target) {
        target_hold_ = in.user_target;
      } else if (cfg.zero_neutral_target) {
        target_hold_ = 0;
      } else if (cfg.hold_actual_position) {
        target_hold_ = in.actual_position;
      }
    } else {
      cw = kCwShutdown;
    }

    out.controlword = cw;
    out.target_position = target_hold_;
    return out;
  }

  /**
   * Feed one cycle's WKC validity to advance the fault-reset arming streak. `arm_threshold`
   * is the configured `fault_reset_arm_cycles`. Once `arm_threshold` consecutive valid cycles
   * elapse the automatic fault reset becomes permitted.
   */
  void noteCycleValidity(bool wkc_valid, int arm_threshold) {
    if (wkc_valid) {
      if (valid_pdo_streak_ < arm_threshold * 4) {
        ++valid_pdo_streak_;
      }
    } else {
      valid_pdo_streak_ = 0;
    }
    if (!reset_armed_ && valid_pdo_streak_ >= arm_threshold) {
      reset_armed_ = true;
    }
  }

private:
  bool reset_pulse_high_{false};
  bool reset_armed_{false};
  int valid_pdo_streak_{0};
  bool first_cycle_done_{false};
  std::int32_t target_hold_{0};
};

}  // namespace ecdev
