#pragma once

#include "devices/motion_profile.hpp"

#include "eni/eni_model.hpp"

#include <cstdint>
#include <memory>
#include <vector>

namespace ecdev {

class IDeviceProfile;

/** Inputs a factory uses to decide on and build a profile for one ENI slave. */
struct ProfileSelectionInput {
  const eni::SlaveConfig* slave{nullptr};
  /** Initial operating mode baked into the profile at construction (CSP default). Overridable at
   *  runtime via Axis::configure() between prepare() and start(). */
  DriveOpMode op_mode{DriveOpMode::Csp};
  /** Initial auto fault-reset/recover flag (off by default). Overridable via Axis::configure(). */
  bool auto_fault_reset_and_recover{false};
  /** Clear a residual fault present at OP entry (before the drive has ever enabled this run) with a
   *  bounded reset window instead of latching a stop. On by default; mid-run faults stay terminal. */
  bool startup_fault_autoreset{true};
};

/**
 * Builds the device-class profile for one slave. A new device class is supported by adding a new
 * factory; the generic device and orchestration layer never change.
 */
class IProfileFactory {
public:
  virtual ~IProfileFactory() = default;
  virtual const char* name() const = 0;
  /**
   * Claim strength for `slave`: 0 = does not handle this slave, higher = more specific match.
   * The registry picks the highest-claiming factory (deterministic by registration order on ties).
   */
  virtual int claim(const eni::SlaveConfig& slave) const = 0;
  virtual std::unique_ptr<IDeviceProfile> create(const ProfileSelectionInput& in) const = 0;
};

/**
 * Registry of {@link IProfileFactory} plugins. `select()` returns the best-claiming profile for a
 * slave, or null when no factory claims it (the caller then leaves the {@link GenericEniDevice}
 * passive -- raw process-image access only).
 */
class ProfileRegistry {
public:
  void registerFactory(std::unique_ptr<IProfileFactory> factory);
  std::unique_ptr<IDeviceProfile> select(const ProfileSelectionInput& in) const;

  /** The process-wide registry pre-populated with the built-in profiles. */
  static ProfileRegistry& builtin();

private:
  std::vector<std::unique_ptr<IProfileFactory>> factories_;
};

}  // namespace ecdev
