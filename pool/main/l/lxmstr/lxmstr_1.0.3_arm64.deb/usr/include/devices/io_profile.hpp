#pragma once

#include <cstddef>
#include <cstdint>

namespace ecdev {

/**
 * Facade-facing contract for a digital/analog I/O device (CiA 401 family). The `IoModule` facade
 * depends only on this -- never on PDO offsets, CoE objects, or SOEM. Channels are numbered from 0
 * in process-image order. All methods are safe to call from an application thread while the RT
 * cycle runs (backed by lock-free state).
 */
class IIoProfile {
public:
  virtual ~IIoProfile() = default;

  virtual std::size_t digitalInputCount() const noexcept = 0;
  virtual std::size_t digitalOutputCount() const noexcept = 0;
  virtual std::size_t analogInputCount() const noexcept = 0;
  virtual std::size_t analogOutputCount() const noexcept = 0;

  /** Read a digital input/output channel; out-of-range returns false. */
  virtual bool digitalInput(std::size_t channel) const noexcept = 0;
  virtual bool digitalOutput(std::size_t channel) const noexcept = 0;
  /** Command a digital output channel; out-of-range is a no-op. */
  virtual void setDigitalOutput(std::size_t channel, bool value) noexcept = 0;

  /** Read an analog input/output channel (raw counts); out-of-range returns 0. */
  virtual std::int32_t analogInput(std::size_t channel) const noexcept = 0;
  virtual std::int32_t analogOutput(std::size_t channel) const noexcept = 0;
  /** Command an analog output channel (raw counts); out-of-range is a no-op. */
  virtual void setAnalogOutput(std::size_t channel, std::int32_t value) noexcept = 0;
};

}  // namespace ecdev
