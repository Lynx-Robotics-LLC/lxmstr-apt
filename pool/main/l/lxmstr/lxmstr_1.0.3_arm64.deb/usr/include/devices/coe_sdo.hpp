#pragma once

#include <cstdint>

namespace ecmaster {
class EcMaster;
}

/**
 * Single source of truth for the small CoE (CANopen over EtherCAT) SDO helpers that the
 * device layer needs during PreOP / SAFE_OP configuration. They route every transfer through
 * the backend-neutral `ecmaster::EcMaster` (SDO read/write + abort capture + error draining), so
 * the device layer no longer depends on any EtherCAT backend header.
 *
 * The read helpers diverge only in *one* dimension — what they do with the CoE error queue after
 * the transfer — so that single decision is made explicit via `SdoDrain` rather than forking the
 * implementation per call site. `CiA402Device` drains unconditionally; the `debug` and
 * diagnostic-example call sites leave the queue intact so the abort code can be recovered.
 */
namespace ecdev::coe {

/** Post-transfer policy for the CoE error queue. */
enum class SdoDrain {
  kNever,   ///< Leave the queue untouched (caller inspects/pops it).
  kAlways,  ///< Drain every queued error after the transfer (success or failure).
};

/** Drain every queued CoE/SoE error so a later read does not see a stale abort. */
void drainErrors(ecmaster::EcMaster& master);

/** Read a UINT16 SDO. Returns false on transfer failure or short read. */
bool tryReadSdoU16(ecmaster::EcMaster& master, std::uint16_t slave, std::uint16_t idx,
                   std::uint8_t sub, std::uint16_t* out, SdoDrain drain = SdoDrain::kNever);

/** Read a UINT32 SDO (single-access only). Returns false on transfer failure or short read. */
bool tryReadSdoU32(ecmaster::EcMaster& master, std::uint16_t slave, std::uint16_t idx,
                   std::uint8_t sub, std::uint32_t* out, SdoDrain drain = SdoDrain::kNever);

/**
 * Robust UINT32 read for vendor scalar objects that some firmware exposes only via complete
 * access, or as a UINT16. Tries single-access, then complete-access, then a non-zero UINT16
 * fallback. Drains on success; captures the CoE abort code into `abort_out` on each failed attempt.
 */
bool tryReadSdoU32WithAbort(ecmaster::EcMaster& master, std::uint16_t slave, std::uint16_t idx,
                            std::uint8_t sub, std::uint32_t* out, std::int32_t* abort_out);

/**
 * Write a UINT16 SDO. When `abort_code_out` is non-null it captures the CoE abort code reported
 * for this transfer (0 on success). Returns the working counter (`> 0` on success).
 */
int writeSdoU16WithAbort(ecmaster::EcMaster& master, std::uint16_t slave, std::uint16_t idx,
                         std::uint8_t sub, std::uint16_t value, std::int32_t* abort_code_out);

/** Write a UINT16 SDO, draining any resulting error. Returns the working counter. */
int writeSdoU16SoftFail(ecmaster::EcMaster& master, std::uint16_t slave, std::uint16_t idx,
                        std::uint8_t sub, std::uint16_t value);

/**
 * Retry `writeSdoU16WithAbort` up to `attempts` times, sleeping `retry_delay_us` between tries
 * and draining stale errors so a prior abort cannot masquerade as the next result. Returns early
 * with the abort code captured when the drive reports a hard abort.
 */
int writeSdoU16WithRetry(ecmaster::EcMaster& master, std::uint16_t slave, std::uint16_t idx,
                         std::uint8_t sub, std::uint16_t value, std::int32_t* abort_code_out,
                         int attempts, int retry_delay_us = 5000);

}  // namespace ecdev::coe
