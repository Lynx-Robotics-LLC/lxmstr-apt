#pragma once

#include "devices/device.hpp"
#include "devices/pdo_assignment.hpp"
#include "devices/process_image.hpp"

#include "eni/eni_model.hpp"

#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace ecdev {

class IDebugTracer;
class IDeviceProfile;

/**
 * Generic, device-class-agnostic EtherCAT slave driven entirely by its ENI `<Slave>` description.
 *
 * Responsibilities (the substrate that every device shares, regardless of class):
 *   - Holds the slave's {@link ProcessImage} (offset tables from the ENI PDOs).
 *   - Replays the ENI's CoE InitCmds (PreOP best-effort + SAFE_OP confirmed).
 *   - Owns an optional {@link IDeviceProfile} that adds device-class behaviour (CiA 402 drive,
 *     CiA 401 I/O, CiA 406 encoder, ...). With no profile attached, the device is a passive
 *     process-image carrier (raw access via the profile/facade or diagnostics).
 *
 * It implements {@link IEthercatDevice}, so the orchestration layer treats every slave uniformly;
 * all device-class-specific knowledge lives in the attached {@link IDeviceProfile}.
 */
class GenericEniDevice : public IEthercatDevice {
public:
  explicit GenericEniDevice(const eni::SlaveConfig& slave);
  ~GenericEniDevice() override;

  /** Attach the device-class profile selected by the registry (may be null = passive). */
  void setProfile(std::unique_ptr<IDeviceProfile> profile);
  IDeviceProfile* profile() noexcept { return profile_.get(); }
  const IDeviceProfile* profile() const noexcept { return profile_.get(); }

  /** The slave's process-image accessor (offset tables). Bound to live PDO bytes per cycle. */
  ProcessImage& processImage() noexcept { return image_; }
  const ProcessImage& processImage() const noexcept { return image_; }

  const eni::SlaveConfig& slaveConfig() const noexcept { return slave_; }

  /* ---- IEthercatDevice ---- */
  const DeviceInfo& info() const override { return info_; }
  void setMaxBringupState(BringupState state) noexcept override { max_bringup_state_ = state; }
  BringupState maxBringupState() const noexcept override { return max_bringup_state_; }
  int configurePreOp(ecmaster::SlaveContext& ctx) override;
  void prepareSafeOp(ecmaster::SlaveContext& ctx) override;
  void writeOutputs(PdoView& pdo, std::uint64_t cycle_count) override;
  void readInputs(const PdoView& pdo, bool wkc_valid, bool operational) override;
  void primeProcessOutputs(PdoView& pdo) override;
  void reportExitStatus(std::ostream& os) const override;
  void captureExitDiagnostics(ecmaster::SlaveContext& ctx) override;

  std::string configureError() const override { return configure_error_; }
  std::string safeOpPrepareError() const override { return safeop_prepare_error_; }

  void prepareShutdown() override;
  bool readyForShutdown() const noexcept override;
  bool requiresMotionShutdown() const noexcept override;
  bool requiresAlShutdown() const noexcept override;
  bool hasLeftOperationEnabled() const noexcept override;
  bool readyForAlShutdown() const noexcept override;
  bool cyclicStopRequested() const noexcept override;
  std::string cyclicStopReason() const override;
  std::uint16_t lastStatusWordForDiagnostics() const noexcept override;

  void setTracer(IDebugTracer* tracer) override;

private:
  /** Confirmed CoE replay (write + readback) for a transition; fills failures string. */
  int replayCoeInitCmdsConfirmed(ecmaster::SlaveContext& ctx, const char* transition,
                                 std::string* failures, int* failure_count);

  eni::SlaveConfig slave_;
  DeviceInfo info_{};
  BringupState max_bringup_state_{BringupState::PreOp};  ///< ESM ceiling; raised via facade configure().
  ProcessImage image_;
  PdoAssignment pdo_assignment_;  ///< ENI-driven PDO assignment programmed in PreOP.
  std::string name_;  ///< Owns the string info_.display_name points at.
  std::unique_ptr<IDeviceProfile> profile_;

  IDebugTracer* tracer_{nullptr};

  std::string configure_error_;
  std::string safeop_prepare_error_;
};

}  // namespace ecdev
