#pragma once

namespace ecdev {

/**
 * How the EtherCAT bus synchronizes PDO cycles with the slave's internal control loop.
 *
 * **DcSync0** (default): every slave is driven by a SYNC0 pulse emitted from its own
 *   distributed-clocks unit at a programmed period. The master times its PDO transmission
 *   against the reference-slave's DC clock (`ecSyncToDc` PI controller). Each cycle is
 *   enforced: on a DC-strict slave any PDO frame arriving more than a few µs off the
 *   SYNC0 phase latches the slave's synchronization-controller fault (typically
 *   `0x603F=0x8700` in CiA-402). Target hosts: PREEMPT_RT + isolated CPU + SCHED_FIFO
 *   with measured `[dc-sync] max` well under the slave's configured sync-error window
 *   (a few µs on most servo drives, larger on I/O slaves).
 *
 * **SmEvent** (non-RT friendly): the slave's control loop is triggered by SM2/SM3
 *   sync-manager events — i.e. the arrival of the LRW frame itself. No SYNC0 pulse, no
 *   DC-strict phase enforcement, and consequently no per-cycle `[dc-sync]` metric. The
 *   drive's SM watchdog (typically 50–100 ms) is the only timing constraint, which is
 *   trivially met by any Linux userspace master. Target hosts: stock Linux kernel, or
 *   cases where you don't want firmware faults from the occasional scheduler outlier.
 *   Tradeoff: position-loop latency variability equals host scheduler jitter (tens of
 *   µs on stock Linux), so the motion command is applied one cycle later and with
 *   slightly more jitter than DC-mode.
 *
 * **Hardware requirement for SmEvent:** the slave must advertise SM-synchronous operation in
 *   SDO `0x1C32:04` / `0x1C33:04` (ETG bitmask, bit0 = SM-event). Many CiA402 servos only
 *   expose DC-Sync0 (bit1) and abort writes to `0x1C32:01` / `0x1C33:01` with value `1`;
 *   the CiA 402 profile detects this in PreOP and fails fast with a clear `configureError()`
 *   instead of timing out at OP with AL 0x0027.
 *
 * The enum is shared between `devices` (where device-specific PreOP writes live)
 * and `ecnet` (which configures the master's DC registers + PI controller).
 */
enum class SyncMode {
  DcSync0,
  SmEvent,
};

}  // namespace ecdev
