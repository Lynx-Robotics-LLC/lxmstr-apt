#pragma once

#include <cstdint>

/**
 * Single home for the two distinct distributed-clock host-vs-SYNC0 phase computations used
 * across the library. They look similar but answer different questions, so both live here
 * rather than being copy-pasted into the examples:
 *
 *   1. `ecSyncToDc` — the production phase-lock PI. Drives `clock_nanosleep` so the host's
 *      cyclic wake converges onto the reference slave's DC time. Used by `EcNetwork::start()`
 *      (SAFE_OP warmup) and `CyclicExecutor::run()` (steady-state OP). Error is computed
 *      against a *tracked expected DC time* (not a modulo), so after lock the reported error
 *      converges toward zero — it is a control signal, not a measurement.
 *
 *   2. `ecSyncToDcMeasure` — the diagnostic phase-error *measurement* used by the SAFE_OP
 *      probe tool (`network_probe`). Error is the SYNC0-relative phase via a modulo wrap, so
 *      it is bounded to ±cycle/2 and represents exactly what a DC-strict drive's sync-error
 *      window enforces each cycle. The tool's verdict logic depends on that bounded-measurement
 *      semantics; do NOT substitute `ecSyncToDc` here.
 *
 * Both keep all state caller-owned so warmup and the RT loop can hand it off trivially.
 */
namespace ecnet::detail {

/* Default PI gains / clamp for the diagnostic phase-error measurement (`ecSyncToDcMeasure`)
 * used by `network_probe`: proportional 1/20, integral 1/4, and a 100 us clamp on `|toff|`. */
inline constexpr std::int32_t kProbeMeasureKpDiv = 20;
inline constexpr std::int32_t kProbeMeasureKiDiv = 4;
inline constexpr std::int32_t kProbeMeasureToffClampNs = 100'000;

/* ------------------------------------------------------------------------------------------
 * (1) Production phase-lock PI (SOEM red_test `ec_sync` family, expected-time model).
 *
 * State is caller-owned (`toff_ns`, `integral`, `expected_dc_reftime_ns`, `initialized`)
 * so warmup and RT loop trivially hand off. Returns the *signed phase error* (`error`)
 * before this cycle's correction, so the caller can record a host-vs-DC histogram without
 * re-deriving it.
 *
 * `kp_div` / `ki_div` are proportional / integral divisors (effective gain 1/N). A divisor
 * of 0 disables that term.
 *
 * Error is the raw difference between the slave's reported DC time and the master's
 * *expected* DC time at this cycle:
 *
 *     error = dc_reftime - expected
 *
 * `expected` advances by **nominal `cycle_ns` only** (NOT `cycle_ns + toff`). Initial
 * offset is captured on the first call (`*initialized = false`) — `expected` is seeded to
 * `dc_reftime + cycle_ns` and the first call returns error=0, toff=0 (no correction).
 *
 * **Why `expected += cycle_ns` and not `cycle_ns + toff`.** If `expected` tracked
 * `cycle_ns + toff`, the controller's own correction would be absorbed into the reference
 * and the per-cycle error change would become independent of `toff`, causing unbounded
 * integrator wind-up. Advancing by nominal `cycle_ns` lets the PI converge to
 * `toff_SS = -s * cycle_ns` with bounded integral for host/slave crystal drift `s`.
 *
 * The integrator is magnitude-accumulating (`*integral += error`). There is no clamp on
 * `toff` and no `target_offset_ns` — whatever phase between master wake and SYNC0 exists
 * at initialization is what the controller locks onto.
 *
 * **Initialization.** The first call always initializes state, applies no correction
 * (`*toff_ns = 0`), and returns `0`. The caller must set `*initialized = false` before
 * the very first invocation; subsequent invocations must leave the flag alone.
 * ------------------------------------------------------------------------------------------ */
inline std::int64_t ecSyncToDc(std::int64_t dc_reftime_ns, std::int64_t cycle_ns,
                               std::int64_t* toff_ns, std::int64_t* integral,
                               std::int64_t* expected_dc_reftime_ns, bool* initialized,
                               std::int32_t kp_div, std::int32_t ki_div) {
  if (!*initialized) {
    /* Capture the master's current phase relationship with the slave's DC clock as the
     * baseline. The very next cycle's `dc_reftime` should be `dc_reftime + cycle_ns`
     * if everything is in lockstep, so we seed `expected` accordingly. First-cycle
     * error is therefore zero by definition and no correction is applied. */
    *expected_dc_reftime_ns = dc_reftime_ns + cycle_ns;
    *integral = 0;
    *initialized = true;
    *toff_ns = 0;
    return 0;
  }
  const std::int64_t error_ns = dc_reftime_ns - *expected_dc_reftime_ns;
  const std::int64_t p_term = (kp_div > 0) ? (error_ns / kp_div) : 0;
  *integral += error_ns;
  const std::int64_t i_term = (ki_div > 0) ? (*integral / ki_div) : 0;
  *toff_ns = -p_term - i_term;
  /* Advance `expected` by nominal `cycle_ns` only — NOT by `cycle_ns + toff`.
   *
   * Advancing by `cycle_ns + toff` would mean expected tracks the host's intentional
   * deadline shift step-for-step, which absorbs the controller's own correction into
   * the reference and blinds it to drift (error_change = s * cycle_ns regardless of
   * toff → integral winds up unbounded → toff grows unbounded → loop runs at
   * many-ms cycles → drive faults). Advancing by `cycle_ns` only lets the PI see
   * `toff_N + s * cycle_ns` as the per-cycle error change, so it can converge to
   * `toff_SS = -s * cycle_ns` with bounded integral. See header comment for the full
   * algebra. */
  *expected_dc_reftime_ns += cycle_ns;
  return error_ns;
}

/* ------------------------------------------------------------------------------------------
 * (2) Diagnostic phase-error measurement (modulo-wrap model).
 *
 * Returns the SYNC0-relative phase of `dc_reftime_ns`, wrapped into [-cycle/2, +cycle/2],
 * and advances a sign-accumulating integrator to derive `*toff_ns`. The returned value is a
 * direct *measurement* of how far out of phase the host wake is from the SYNC0 pulse — the
 * exact quantity a DC-strict drive's sync-error window is enforced against. Bounded to
 * ±cycle/2 by construction, so a missed full cycle is invisible here (callers detect that
 * via raw period jitter instead).
 *
 * `kp_div` / `ki_div` are proportional / integral divisors (gain 1/N, 0 disables the term).
 * `toff_clamp_ns > 0` clamps `|toff|`. `target_offset_ns` is the desired phase between the
 * master wake and SYNC0 (SOEM red_test uses 50000 ns).
 *
 * State is caller-owned (`toff_ns`, `integral`); no initialization handshake is needed
 * because the modulo measurement is stateless per cycle apart from the integrator.
 * ------------------------------------------------------------------------------------------ */
inline std::int64_t ecSyncToDcMeasure(std::int64_t dc_reftime_ns, std::int64_t cycle_ns,
                                      std::int64_t* toff_ns, std::int64_t* integral,
                                      std::int32_t kp_div, std::int32_t ki_div,
                                      std::int32_t toff_clamp_ns,
                                      std::int64_t target_offset_ns = 50'000) {
  std::int64_t delta = (dc_reftime_ns - target_offset_ns) % cycle_ns;
  if (delta > cycle_ns / 2) delta -= cycle_ns;
  if (delta > 0) (*integral)++;
  if (delta < 0) (*integral)--;
  const std::int64_t p_term = (kp_div > 0) ? (delta / kp_div) : 0;
  const std::int64_t i_term = (ki_div > 0) ? (*integral / ki_div) : 0;
  std::int64_t toff = -p_term - i_term;
  if (toff_clamp_ns > 0) {
    const std::int64_t clamp = static_cast<std::int64_t>(toff_clamp_ns);
    if (toff > clamp) toff = clamp;
    else if (toff < -clamp) toff = -clamp;
  }
  *toff_ns = toff;
  return delta;
}

}  // namespace ecnet::detail
