#pragma once

#include "ecnet/network_config.hpp"

#include "devices/device_bind.hpp"

#include "facade/axis.hpp"
#include "facade/encoder.hpp"
#include "facade/io_module.hpp"

#include "eni/eni_model.hpp"

#include <atomic>
#include <chrono>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <vector>

/* ----------------------------------------------------------------------------
 * Compile-time platform sanity checks. These are belt-and-suspenders for the
 * CMake-level arch gate (CMakeLists.txt, LXMSTR_ALLOW_UNTESTED_ARCH). They
 * catch exotic cross-compiler setups (e.g. little-endian on a big-endian MCU
 * toolchain, non-lock-free 64-bit atomics on embedded libstdc++) that the
 * CMake variables can't see. See docs/dc_sync_tuning.md.
 * ---------------------------------------------------------------------------- */

static_assert(sizeof(void*) == 8,
              "LXMSTR requires a 64-bit target. 32-bit ARM/x86/MIPS/RISC-V are unsupported "
              "because they trap on unaligned PDO accesses and lack native 64-bit atomics.");

#if defined(__BYTE_ORDER__) && defined(__ORDER_LITTLE_ENDIAN__)
static_assert(__BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__,
              "LXMSTR requires a little-endian host. EtherCAT is little-endian on the wire and "
              "SOEM assumes host endianness matches; big-endian hosts would need byte-swapping "
              "throughout the PDO layer which is not implemented.");
#endif

static_assert(std::atomic<std::uint64_t>::is_always_lock_free,
              "LXMSTR requires lock-free 64-bit atomics. The cyclic executor's SPSC debug ring "
              "and jitter counters are updated from the RT thread and must not spin on a mutex.");
static_assert(std::atomic<std::int64_t>::is_always_lock_free,
              "LXMSTR requires lock-free 64-bit atomics (signed variant).");

namespace ecmaster {
class EcMaster;
class ISlaveHandler;
}

namespace ecdev {
class IDebugTracer;
}

namespace ecnet {

class CyclicExecutor;

/**
 * User-facing runtime facade for an EtherCAT network. Owns the SOEM master, the cyclic RT
 * thread, and the devices auto-created from the ENI. A typical program is:
 *
 *   ecnet::NetworkConfig cfg = ecnet::NetworkConfig::defaults();  // iface from LXMSTR_RT_IFACE
 *   cfg.eni.eni_path = "network.eni.xml";   // required: ENI is the only setup mode and the
 *                                           // sole source of the cyclic period (CycleTime).
 *   ecnet::EcNetwork net(cfg);
 *   if (!net.start()) { std::cerr << net.lastError(); return 1; }
 *   auto axis = net.axes().front();
 *   ... axis->moveTo(axis->actualPosition()); ...
 *   net.stop();
 *
 * No SOEM types leak through this API. `start()` loads + validates the ENI, verifies it
 * against the scanned hardware, and creates one generic CiA402 device per <Slave>.
 *
 * Two-phase bring-up (per-axis configuration). Operating mode and fault policy are per-axis intent
 * the application sets on each discovered drive before the bus is brought up. `prepare()` runs the
 * offline + PRE_OP phases so `axes()` becomes valid while the drives are still in PRE_OP and no mode
 * has been committed; the application then configures each axis and calls `start()` to finish:
 *
 *   ecnet::EcNetwork net(cfg);
 *   if (!net.prepare()) { std::cerr << net.lastError(); return 1; }
 *   for (ecfacade::Axis* ax : net.axes()) { ax->setDriveMode(ecdev::DriveOpMode::Cst); ax->configure(); }
 *   if (!net.start()) { std::cerr << net.lastError(); return 1; }
 *
 * `start()` calls `prepare()` itself when it has not run, so the single-call form above still works.
 */
class EcNetwork {
public:
  /** End-of-run jitter summary (populated by the cyclic thread). */
  struct JitterStats {
    std::int64_t min_ns{0};
    std::int64_t max_ns{0};
    std::int64_t mean_ns{0};
    std::int64_t mean_abs_ns{0};
    std::uint64_t samples{0};
  };

  /** End-of-run DC-sync alignment summary (host wake vs reference-slave DC clock). */
  struct DcSyncStats {
    std::int64_t min_ns{0};
    std::int64_t max_ns{0};
    std::int64_t mean_ns{0};
    std::int64_t mean_abs_ns{0};
    std::uint64_t samples{0};
    std::int64_t final_integral{0};
  };

  /** Cached at `stop()` from the cyclic executor's sync trace ring (see `NetworkConfig::sync_trace_capacity`). */
  struct SyncTraceReport {
    std::vector<SyncTraceSample> samples;
    std::uint64_t total_writes{0};
    std::size_t ring_capacity{0};
    /** Cycles where `|dc_delta|` exceeded `NetworkConfig::sync_trace_window_ns` (window == 0 ⇒ always 0). */
    std::uint64_t violation_count{0};
  };

  explicit EcNetwork(NetworkConfig cfg);
  ~EcNetwork();

  EcNetwork(const EcNetwork&) = delete;
  EcNetwork& operator=(const EcNetwork&) = delete;

  /**
   * Phase 1 of bring-up: applies RT scheduling, loads + validates the ENI, opens the NIC, verifies
   * the scanned hardware, reaches PRE_OP, and binds devices so that `axes()` / `ioModules()` /
   * `encoders()` become valid. Crucially it stops *before* any per-device CoE configuration, so the
   * application can set per-axis intent (e.g. `axis->setOperatingMode(...)`) on the discovered
   * drives before the operating mode is committed to the drive in `start()`. Returns true on
   * success; false + `lastError()` on failure (which tears down what was initialized). Idempotent:
   * a second call after success is a no-op success. Calling it after `start()` is an error.
   */
  bool prepare();

  /**
   * Phase 2 of bring-up (runs `prepare()` first if it has not been called): per-device CoE
   * configuration (commits each drive's operating mode to 0x6060), configures DC, reaches SAFE_OP +
   * OPERATIONAL, and spawns the cyclic thread. Returns true on success; false + `lastError()`
   * on failure. Failures at any step tear down what was initialized.
   */
  bool start();

  /** Stop the cyclic thread and close the master. Safe to call multiple times. */
  void stop();

  /** True once the cyclic thread is live, false after `stop()` or on failure. */
  bool isRunning() const noexcept;
  /** Cyclic period in ns, adopted from the ENI's `<Config><Cyclic><CycleTime>`. Valid (non-zero)
   *  after a successful `start()`; 0 before the ENI is loaded. */
  std::uint32_t cycleTimeNs() const noexcept;
  /** Synchronization mode resolved from the ENI (DcSync0 when the bus carries a SYNC0 device,
   *  else SmEvent). Valid after `prepare()` / `start()`. Not an app input -- the ENI decides. */
  SyncMode syncMode() const noexcept;
  /** Total cycles executed by the RT thread since `start()`. */
  std::uint64_t cycleCount() const noexcept;
  /** Last human-readable error captured from the library (thread-safe). Includes `[shutdown]`
   *  step failures accumulated during `stop()` after the cyclic thread has been joined. */
  std::string lastError() const;
  /** Snapshot of cycle-timing jitter (updated throughout the run; final at `stop()`). */
  JitterStats jitterStats() const noexcept;

  /**
   * Snapshot of DC-sync alignment quality (host cyclic wake vs reference-slave DC clock,
   * the error before the PI controller corrects it). `samples == 0` outside DC-aligned mode.
   */
  DcSyncStats dcSyncStats() const noexcept;

  /**
   * Per-cycle DC-sync + host jitter capture from the last session (`NetworkConfig::sync_trace_capacity`).
   * Populated when `stop()` joins the executor; empty if tracing was off or the bus never ran.
   */
  SyncTraceReport syncTraceReport() const noexcept { return sync_trace_last_; }

  /**
   * Live violation tally while the cyclic thread is running (`sync_trace_window_ns` > 0).
   * After `stop()`, prefer `syncTraceReport().violation_count`.
   */
  std::uint64_t syncTraceViolationCount() const noexcept;
  /**
   * Print each device's exit status via `reportExitStatus` to `os`. Call after `stop()` to
   * surface device-specific end-of-run diagnostics (e.g. final statusword, CiA402 fault code 0x603F).
   */
  void reportDeviceStatus(std::ostream& os) const;

  /**
   * Motion axes in bus order, one per slave whose auto-selected profile exposes a motion
   * interface (e.g. CiA402 drives). Valid after a successful `start()`; the storage is owned by
   * this `EcNetwork`. This is the high-level handle a PLC/application programmer uses
   * (`axes()[0]->moveTo(...)`) -- it never exposes CiA profiles, the ENI, or SOEM.
   */
  std::vector<ecfacade::Axis*> axes() const;

  /** I/O modules in bus order (slaves whose profile exposes a digital/analog I/O interface). */
  std::vector<ecfacade::IoModule*> ioModules() const;

  /** Encoders in bus order (slaves whose profile exposes an encoder interface). */
  std::vector<ecfacade::Encoder*> encoders() const;

private:
  /** Register an ENI-described device carrying its bus position + identity for position-aware bind. */
  void addEniDeviceImpl(const eni::SlaveConfig& slave,
                        std::unique_ptr<ecdev::IEthercatDevice> device);
  void setError(std::string msg);
  void appendShutdownError(std::string msg);
  void shutdownLog(std::string_view msg) const;
  /** Debug-only: fresh SDO fault snapshot on every bound device (`NetworkConfig::debug`). */
  void debugShutdownFaultMilestone(const char* label);
  void waitDeviceShutdownSteps();
  /**
   * Poll every 2 ms until `satisfied` holds for *every* bound device, the deadline passes, or
   * the executor stops cycling. Returns true iff all devices satisfied the predicate in time.
   * Devices a step does not care about make their predicate return true trivially.
   */
  bool waitUntilAllDevices(const std::function<bool(const ecdev::IEthercatDevice&)>& satisfied,
                           std::chrono::steady_clock::time_point deadline) const;
  /** Build "device <step> timeout after <ms> ms[ slave i sw=0x..]" for devices matching `include`. */
  std::string formatShutdownTimeout(
      const char* step, int timeout_ms,
      const std::function<bool(const ecdev::IEthercatDevice&)>& include) const;
  void teardown();

  /* --- Bring-up pipeline -----------------------------------------------------------------
   * `start()`'s body, re-expressed as an explicit ordered chain of named phases. Each phase
   * is a small step with a single responsibility; on failure it records `setError()` and
   * returns false, and the `start()` driver tears down and aborts. The order encodes the
   * fragile EtherCAT bring-up contract (see the run-order comment in `start()`); it must not
   * be reordered. Phases that cannot fail return true. */
  bool bringUpInitMaster();        /* open NIC, configInit */
  bool bringUpVerifyEni();         /* (ENI mode) compare ENI vs scanned ec_slave[] identity */
  bool bringUpReachInit();         /* force all slaves to INIT (clear stale ESM latches) */
  bool bringUpReachPreOp();        /* walk back up to PRE_OP for CoE configuration */
  bool bringUpBindDevices();       /* match pending devices to slaves */
  bool bringUpMapAndConfigure();   /* configMap (+ retries) + per-device configureError */
  /** First non-empty `configureError()` among bound devices, or "" if all configured cleanly. */
  std::string firstDeviceConfigureError() const;
  bool bringUpConfigureDc();       /* configDc + per-slave SYNC0 activation from ENI <DC> */
  bool bringUpPrimeOutputs();      /* prime output PDO before SAFE_OP */
  bool bringUpEnterSafeOp();       /* ensureSafeOperational + PDO warmup */
  bool bringUpPrepareSafeOp();     /* device prepareSafeOp() + safeOpPrepareError */
  bool bringUpDebugProbes();       /* optional debug DC / strict-sync checks */
  bool bringUpComputeBusParams();  /* expected WKC, DC-aligned flag, debug PDO info */
  bool bringUpLaunchExecutor();    /* spawn RT thread, request OP entry, wait for OPERATIONAL */

  NetworkConfig cfg_;
  SyncTraceReport sync_trace_last_{};

  std::vector<ecdev::PendingDevice> pending_;

  /**
   * Load+validate `cfg_.eni.eni_path` against the embedded schema, then auto-create one
   * generic CiA402 device per <Slave> (offline, before NIC open). Verified against the live
   * bus in `bringUpVerifyEni()`.
   */
  bool loadAndValidateEni();
  void createDevices();
  eni::EniModel eni_model_;
  bool eni_loaded_{false};

  /* Populated by `start()`. */
  std::unique_ptr<ecmaster::EcMaster> master_;
  std::vector<std::unique_ptr<ecmaster::ISlaveHandler>> handler_storage_;
  std::vector<ecdev::IEthercatDevice*> bound_devices_;  /* index 0 unused (SOEM 1-based). */
  /* User-facing motion handles, one per bound device that exposes IMotionProfile. Built after
   * binding; the Axis objects reference profiles owned by the bound devices. */
  std::vector<ecfacade::Axis> axes_storage_;
  std::vector<ecfacade::IoModule> io_storage_;
  std::vector<ecfacade::Encoder> encoder_storage_;
  void buildFacades();
  std::unique_ptr<ecdev::IDebugTracer> tracer_;
  /* Active tracer for the current bring-up: either `tracer_` (debug) or the shared null
   * tracer. Set in `start()`'s prologue and consumed by the bring-up phases + executor. */
  ecdev::IDebugTracer* active_tracer_{nullptr};
  std::unique_ptr<CyclicExecutor> executor_;
  int expected_wkc_{0};
  bool dc_aligned_{false};

  /* Per-device bring-up targeting. Built once per start() from each bound device's
   * maxBringupState(). `safeop_slaves_` are the 1-based indices to walk PRE_OP → SAFE_OP
   * (max >= SafeOp); `op_slaves_` are the subset to additionally drive to OP (max == Op).
   * Devices left at the default PRE_OP appear in neither list and are held in PRE_OP. */
  std::vector<std::uint16_t> safeop_slaves_;
  std::vector<std::uint16_t> op_slaves_;
  void computeBringupStateLists();

  /**
   * Snapshot of each slave's EtherCAT state + AL-status code taken while the master is still
   * open (the last thing `stop()` does before `master_->close()`). `reportDeviceStatus()`
   * prints from this so the operator sees what the bus actually looked like at shutdown
   * instead of the zeroed `ec_slave[]` you get after the NIC socket is closed. Index 0 is
   * unused to match SOEM's 1-based slave numbering.
   */
  struct SlaveSnapshot {
    std::uint16_t state{0};
    std::uint16_t al_statuscode{0};
    bool valid{false};
    bool is_lost{false};
  };
  std::vector<SlaveSnapshot> exit_snapshot_;

  /** Structured bus fault pulled from the executor at `stop()` when the watchdog tripped.
   *  `reportDeviceStatus()` prints `description` and marks `lost_slaves`. */
  BusFault bus_fault_;

  mutable std::mutex err_mutex_;
  std::string last_error_;
  /** True once `prepare()` has reached PRE_OP with devices bound; reset by `teardown()`/`stop()`. */
  bool prepared_{false};
  std::atomic<bool> started_{false};
};

}  // namespace ecnet
