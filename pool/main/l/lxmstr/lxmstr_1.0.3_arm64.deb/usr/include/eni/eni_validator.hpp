#pragma once

#include <string>
#include <vector>

namespace eni {

/** Outcome of validating an ENI document against the embedded ETG.2100 schema. */
struct ValidationResult {
  bool ok{false};
  std::vector<std::string> errors;   ///< Human-readable schema / parse errors.
};

/**
 * Validate an ENI file against the project-bundled EtherCATConfig.xsd (embedded
 * into the binary, see embedded_xsd.hpp) using libxml2. There is no schema-path
 * argument by design: the schema always ships with the binary.
 */
ValidationResult validateEniFile(const std::string& eni_path);

/** Same as validateEniFile but for an in-memory document. */
ValidationResult validateEniString(const std::string& eni_xml);

}  // namespace eni
