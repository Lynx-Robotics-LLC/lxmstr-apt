#pragma once

#include "eni/eni_model.hpp"

#include <string>

namespace eni {

/** Outcome of parsing an ENI file into an EniModel. */
struct ReadResult {
  bool ok{false};
  std::string error;
  EniModel model;
};

/**
 * Parse an ETG.2100 EtherCATConfig (ENI) document into an EniModel. This is the
 * inverse of the eni_gen tool's EniBuilder: it reads <Slave> identity, the
 * sync-manager settings, Rx/Tx PDOs with their entries, the mailbox CoE init
 * commands, and DC settings — everything the generic runtime needs to build a
 * CiA402 device without vendor C++.
 *
 * The reader assumes the document is already schema-valid (the runtime validates
 * first), so it is tolerant of missing optional elements but does not duplicate
 * full schema enforcement.
 */
ReadResult readEniFile(const std::string& eni_path);

/** Same as readEniFile but for an in-memory document. */
ReadResult readEniString(const std::string& eni_xml);

}  // namespace eni
