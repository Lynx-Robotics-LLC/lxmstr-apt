#pragma once

#include "devices/encoder_profile.hpp"
#include "facade/device_facade.hpp"

#include <cstdint>
#include <string>

namespace ecfacade {

/**
 * High-level encoder handle. Thin wrapper over an {@link ecdev::IEncoderProfile}; the application
 * reads position/velocity/status without seeing CoE objects or SOEM.
 */
class Encoder : public DeviceFacade {
public:
  Encoder(ecdev::IEncoderProfile* enc, std::string name, ecdev::IEthercatDevice* device);

  std::int32_t position() const noexcept;
  std::int32_t velocity() const noexcept;
  std::uint16_t status() const noexcept;

  ecdev::IEncoderProfile* encoderProfile() const noexcept;

private:
  ecdev::IEncoderProfile* enc_;
};

}  // namespace ecfacade
