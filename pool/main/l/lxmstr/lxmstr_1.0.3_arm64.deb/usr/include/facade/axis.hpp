#pragma once

#include "devices/motion_profile.hpp"
#include "facade/device_facade.hpp"

#include <cstdint>
#include <string>

namespace ecfacade {

/**
 * High-level motion handle a PLC/application programmer uses, analogous to a TwinCAT "NC axis".
 *
 * An `Axis` is a thin, safe wrapper over an {@link ecdev::IMotionProfile}. The application never
 * sees CiA402 controlwords, PDO offsets, the ENI, or SOEM: it commands positions and reads back
 * status in engineering-relevant terms. The same `Axis` works for any drive family whose profile
 * implements `IMotionProfile`, so swapping a CiA402 servo for a different drive class does not
 * change application code.
 *
 * All methods are safe to call from the application thread while the RT cycle runs (the backing
 * profile uses lock-free state). Exception: `setDriveMode()` and the inherited `configure()` must
 * only be called between `EcNetwork::prepare()` and `EcNetwork::start()`.
 */
class Axis : public DeviceFacade {
public:
  Axis(ecdev::IMotionProfile* motion, std::string name, ecdev::IEthercatDevice* device);

  /** Select the cyclic operating mode (CSP / CSV / CST) this axis runs; the CiA402 profile writes
   *  0x6060 to match. Call before start() to choose the initial mode, or while running to switch
   *  live -- a live switch takes effect only when the ENI maps 0x6060 into the RxPDO (eni_gen does
   *  this for CiA402 drives). RT-safe. */
  void setDriveMode(ecdev::DriveOpMode mode) noexcept;

  /* ---- Commands ---- */
  /** Command an absolute target position in encoder counts (CSP). */
  void moveTo(std::int32_t counts) noexcept;
  /** Command a target velocity in encoder counts/s (CSV). */
  void moveAtVelocity(std::int32_t counts_per_sec) noexcept;
  /** Command a target torque in per-mille of rated torque (CST). */
  void applyTorque(std::int32_t per_mille_rated) noexcept;
  /** Request the drive to power up and hold position. */
  void enable() noexcept;
  /** Request the drive to power down to a de-energised resting state. */
  void disable() noexcept;
  /** Clear a latched drive fault (one-shot). */
  void resetFault() noexcept;

  /* ---- Status ---- */
  std::int32_t actualPosition() const noexcept;
  std::int32_t commandedPosition() const noexcept;
  std::int32_t actualVelocity() const noexcept;
  bool isEnabled() const noexcept;
  bool isFaulted() const noexcept;
  std::uint16_t statusword() const noexcept;
  /** Drive-reported actual torque (0x6077, per-mille of rated); 0 if the profile doesn't map it. */
  std::int32_t actualTorque() const noexcept;
  /** Drive-reported modes-of-operation display (0x6061; 8=CSP, 9=CSV, 10=CST); 0 if unmapped. */
  std::int32_t modeDisplay() const noexcept;

  /** Escape hatch for advanced callers that need the underlying motion contract. */
  ecdev::IMotionProfile* motionProfile() const noexcept;

private:
  ecdev::IMotionProfile* motion_;
};

}  // namespace ecfacade
