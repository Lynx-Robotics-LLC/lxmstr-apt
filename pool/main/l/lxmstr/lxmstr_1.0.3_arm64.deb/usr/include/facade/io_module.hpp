#pragma once

#include "devices/io_profile.hpp"
#include "facade/device_facade.hpp"

#include <cstddef>
#include <cstdint>
#include <string>

namespace ecfacade {

/**
 * High-level digital/analog I/O handle. Thin wrapper over an {@link ecdev::IIoProfile}; the
 * application reads/writes named-by-index channels without seeing CoE objects, PDO offsets, or
 * SOEM. Safe to use from the application thread during the RT cycle.
 */
class IoModule : public DeviceFacade {
public:
  IoModule(ecdev::IIoProfile* io, std::string name, ecdev::IEthercatDevice* device);

  std::size_t digitalInputCount() const noexcept;
  std::size_t digitalOutputCount() const noexcept;
  std::size_t analogInputCount() const noexcept;
  std::size_t analogOutputCount() const noexcept;

  bool readDigital(std::size_t channel) const noexcept;
  bool digitalOutputState(std::size_t channel) const noexcept;
  void writeDigital(std::size_t channel, bool value) noexcept;

  std::int32_t readAnalog(std::size_t channel) const noexcept;
  std::int32_t analogOutputState(std::size_t channel) const noexcept;
  void writeAnalog(std::size_t channel, std::int32_t value) noexcept;

  ecdev::IIoProfile* ioProfile() const noexcept;

private:
  ecdev::IIoProfile* io_;
};

}  // namespace ecfacade
