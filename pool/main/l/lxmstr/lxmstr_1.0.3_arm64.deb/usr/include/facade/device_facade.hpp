#pragma once

#include "devices/device.hpp"

#include <string>

namespace ecfacade {

/**
 * Shared base for every application-facing device handle (IoModule, Axis, Encoder).
 *
 * Holds the (non-owning) runtime device pointer and the slave name, and exposes the only
 * app-facing entry point for opting a device into a higher EtherCAT bring-up ceiling. The
 * underlying `ecdev::IEthercatDevice::setMaxBringupState` is library-internal; the application
 * never calls it directly -- it calls `configure()` here instead.
 *
 * Non-polymorphic on purpose: facades are stored by value in homogeneous containers and are never
 * destroyed through a base pointer, so no virtual destructor is required.
 */
class DeviceFacade {
public:
  DeviceFacade(ecdev::IEthercatDevice* device, std::string name);

  /** ENI/ESI slave name this handle maps to (for logs / UI). */
  const std::string& name() const noexcept;

  /**
   * Opt this device into a maximum bring-up state. Call only between `EcNetwork::prepare()` and
   * `EcNetwork::start()`. Not calling `configure()` leaves the device at its default PRE_OP.
   */
  void configure(ecdev::BringupState maxState) noexcept;

  /** Convenience for the common "bring this device fully operational" case (configure(Op)). */
  void configure() noexcept;

protected:
  ecdev::IEthercatDevice* device_;
  std::string name_;
};

}  // namespace ecfacade
