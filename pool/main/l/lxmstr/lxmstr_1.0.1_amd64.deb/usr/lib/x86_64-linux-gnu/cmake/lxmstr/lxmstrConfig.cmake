
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was lxmstrConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/x86_64-linux-gnu/cmake/lxmstr" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

# Public runtime/transitive dependencies of liblxmstr.so (its PUBLIC link interface).
# libsodium (license verification) is linked PRIVATE into the .so, so its symbols
# live inside liblxmstr.so and it is only a runtime (NEEDED) dependency, not a
# link-time requirement for consumers — hence it is intentionally not listed here.
include(CMakeFindDependencyMacro)
find_dependency(Threads)
find_dependency(LibXml2)

include("${CMAKE_CURRENT_LIST_DIR}/lxmstrTargets.cmake")

# Back-compat alias: the demos and external consumers link `lxmstr::ecnet`, which is the
# single merged library exported here as `lxmstr::lxmstr`.
if(NOT TARGET lxmstr::ecnet)
  add_library(lxmstr::ecnet ALIAS lxmstr::lxmstr)
endif()

check_required_components(lxmstr)
