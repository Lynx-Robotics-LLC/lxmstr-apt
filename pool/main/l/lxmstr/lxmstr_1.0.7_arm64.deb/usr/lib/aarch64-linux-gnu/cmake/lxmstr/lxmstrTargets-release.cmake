#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "lxmstr::lxmstr" for configuration "Release"
set_property(TARGET lxmstr::lxmstr APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(lxmstr::lxmstr PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/liblxmstr.so.1.0.7"
  IMPORTED_SONAME_RELEASE "liblxmstr.so.1"
  )

list(APPEND _cmake_import_check_targets lxmstr::lxmstr )
list(APPEND _cmake_import_check_files_for_lxmstr::lxmstr "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/liblxmstr.so.1.0.7" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
